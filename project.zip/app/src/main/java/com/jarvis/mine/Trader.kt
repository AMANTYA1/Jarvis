package com.jarvis.mine

import android.content.Context
import android.content.Intent
import android.widget.Toast
import okhttp3.Request
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

class Candle(val t: Long, val o: Double, val h: Double, val l: Double, val c: Double)

class Signal(val dir: String, val entry: Double, val sl: Double, val tp: Double, val why: String, val key: String)

class SmcResult(val sig: Signal?, val note: String)

fun fmt2(v: Double): String = String.format(Locale.US, "%.2f", v)

// Simple SMC (Smart Money Concepts): structure break (BOS/CHoCH), order block, FVG, liquidity sweep, premium/discount
object Smc {
    private fun atr(cs: List<Candle>, p: Int): Double {
        var sum = 0.0
        var cnt = 0
        for (i in max(1, cs.size - p) until cs.size) {
            val tr = max(cs[i].h - cs[i].l, max(abs(cs[i].h - cs[i - 1].c), abs(cs[i].l - cs[i - 1].c)))
            sum += tr
            cnt++
        }
        return if (cnt == 0) 0.0 else sum / cnt
    }

    fun analyze(cs: List<Candle>, rr: Double): SmcResult {
        if (cs.size < 40) return SmcResult(null, "Data kam hai")
        val n = cs.size
        val last = cs[n - 1]
        if (System.currentTimeMillis() / 1000 - last.t > 45 * 60) {
            return SmcResult(null, "Market band lag raha hai ya data purana hai")
        }
        val atr = atr(cs, 14)
        if (atr <= 0.0) return SmcResult(null, "Data theek nahi hai")

        // swing highs / lows (3 candle each side)
        val sh = ArrayList<Int>()
        val sl = ArrayList<Int>()
        val w = 3
        for (i in w until n - w) {
            var isH = true
            var isL = true
            for (j in 1..w) {
                if (cs[i].h <= cs[i - j].h || cs[i].h <= cs[i + j].h) isH = false
                if (cs[i].l >= cs[i - j].l || cs[i].l >= cs[i + j].l) isL = false
            }
            if (isH) sh.add(i)
            if (isL) sl.add(i)
        }
        if (sh.size < 2 || sl.size < 2) return SmcResult(null, "Structure abhi clear nahi hai")

        // latest structure break in the last 40 candles
        var bk = -1
        var dirUp = true
        var k = n - 1
        while (k >= n - 40 && k > 10 && bk < 0) {
            val ph = sh.lastOrNull { it < k - 1 }
            val pl = sl.lastOrNull { it < k - 1 }
            if (ph != null && cs[k].c > cs[ph].h && ((ph + 1) until k).none { cs[it].c > cs[ph].h }) {
                bk = k
                dirUp = true
            } else if (pl != null && cs[k].c < cs[pl].l && ((pl + 1) until k).none { cs[it].c < cs[pl].l }) {
                bk = k
                dirUp = false
            }
            k--
        }
        if (bk < 0) return SmcResult(null, "Abhi koi fresh structure break nahi hai")

        // order block = last opposite candle before the break move
        var ob = -1
        var j = bk - 1
        if (dirUp) {
            while (j > bk - 12 && j > 0 && cs[j].c >= cs[j].o) j--
            if (cs[j].c < cs[j].o) ob = j
        } else {
            while (j > bk - 12 && j > 0 && cs[j].c <= cs[j].o) j--
            if (cs[j].c > cs[j].o) ob = j
        }
        if (ob < 0) return SmcResult(null, "Order block nahi mila")
        val zlo = cs[ob].l
        val zhi = cs[ob].h

        if (bk + 1 >= n) return SmcResult(null, "Break abhi hua hai, pullback ka intezaar")
        val after = (bk + 1) until n
        if (dirUp) {
            if (after.any { cs[it].c < zlo }) return SmcResult(null, "Buy setup fail ho gaya")
            val touched = after.any { cs[it].l <= zhi }
            val inZone = last.c <= zhi + 0.1 * atr && last.c >= zlo - 0.1 * atr
            if (!touched || !inZone) {
                return SmcResult(null, "Buy zone " + fmt2(zlo) + " se " + fmt2(zhi) + " ka intezaar, price " + fmt2(last.c))
            }
        } else {
            if (after.any { cs[it].c > zhi }) return SmcResult(null, "Sell setup fail ho gaya")
            val touched = after.any { cs[it].h >= zlo }
            val inZone = last.c >= zlo - 0.1 * atr && last.c <= zhi + 0.1 * atr
            if (!touched || !inZone) {
                return SmcResult(null, "Sell zone " + fmt2(zlo) + " se " + fmt2(zhi) + " ka intezaar, price " + fmt2(last.c))
            }
        }

        // premium / discount: buy only in discount, sell only in premium
        val seg = cs.takeLast(80)
        val eq = (seg.maxOf { it.h } + seg.minOf { it.l }) / 2
        val mid = (zlo + zhi) / 2
        if (dirUp && mid > eq) return SmcResult(null, "Buy zone premium side me hai, skip")
        if (!dirUp && mid < eq) return SmcResult(null, "Sell zone discount side me hai, skip")

        // extras for the reason text: liquidity sweep and FVG
        var sweep = false
        if (dirUp) {
            val pl = sl.lastOrNull { it < ob - 1 }
            if (pl != null) sweep = ((pl + 1)..ob).any { cs[it].l < cs[pl].l && cs[it].c > cs[pl].l }
        } else {
            val ph = sh.lastOrNull { it < ob - 1 }
            if (ph != null) sweep = ((ph + 1)..ob).any { cs[it].h > cs[ph].h && cs[it].c < cs[ph].h }
        }
        var fvg = false
        for (i in (ob + 1)..bk) {
            if (i + 1 >= n) break
            if (dirUp && cs[i - 1].h < cs[i + 1].l) fvg = true
            if (!dirUp && cs[i - 1].l > cs[i + 1].h) fvg = true
        }

        val entry = last.c
        val slv = if (dirUp) zlo - 0.25 * atr else zhi + 0.25 * atr
        val risk = abs(entry - slv)
        if (risk < 0.3 * atr || risk > 3.5 * atr) return SmcResult(null, "Risk size theek nahi, skip")
        val tp = if (dirUp) entry + rr * risk else entry - rr * risk
        val why = (if (dirUp) "bullish" else "bearish") + " structure break, order block" +
            (if (fvg) ", FVG" else "") + (if (sweep) ", liquidity sweep" else "")
        return SmcResult(Signal(if (dirUp) "BUY" else "SELL", entry, slv, tp, why, (if (dirUp) "B" else "S") + cs[bk].t), "Setup mila")
    }
}

object Trader {
    @Volatile var running = false
    @Volatile var pending: Signal? = null
    @Volatile var pendingUntil = 0L
    private var lastKey = ""
    private var dayKey = ""
    private var sent = 0
    private var lastTradeAt = 0L

    fun candles(tf: String): List<Candle> {
        return try {
            val url = "https://query1.finance.yahoo.com/v8/finance/chart/XAUUSD=X?interval=$tf&range=5d"
            val req = Request.Builder().url(url)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36").build()
            Net.client.newCall(req).execute().use { r ->
                if (r.code >= 400) return emptyList()
                val res = JSONObject(r.body?.string() ?: "").getJSONObject("chart").getJSONArray("result").getJSONObject(0)
                val ts = res.getJSONArray("timestamp")
                val q = res.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0)
                val o = q.getJSONArray("open")
                val hi = q.getJSONArray("high")
                val lo = q.getJSONArray("low")
                val c = q.getJSONArray("close")
                val out = ArrayList<Candle>()
                for (i in 0 until ts.length()) {
                    if (o.isNull(i) || hi.isNull(i) || lo.isNull(i) || c.isNull(i)) continue
                    out.add(Candle(ts.getLong(i), o.getDouble(i), hi.getDouble(i), lo.getDouble(i), c.getDouble(i)))
                }
                out
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun text(s: Signal, ask: Boolean): String =
        "Gold " + (if (s.dir == "BUY") "buy" else "sell") + " setup. Entry " + fmt2(s.entry) + ", stop loss " + fmt2(s.sl) +
            ", target " + fmt2(s.tp) + ". Wajah: " + s.why + "." + (if (ask) " Order lagau? Haan ya nahi bolo." else "")

    fun setOn(c: Context, on: Boolean) {
        c.getSharedPreferences("j", Context.MODE_PRIVATE).edit().putBoolean("trade_on", on).apply()
        if (on) start(c) else { running = false; Agent.stop = true }
    }

    fun start(c: Context) {
        if (running) return
        running = true
        val app = c.applicationContext
        Thread { loop(app) }.start()
    }

    private fun loop(c: Context) {
        while (running) {
            try { tick(c) } catch (e: Exception) { }
            val tf = c.getSharedPreferences("j", Context.MODE_PRIVATE).getString("trade_tf", "15m") ?: "15m"
            val wait = if (tf == "1m") 20 else if (tf == "5m") 40 else 60
            var i = 0
            while (running && i < wait) { Thread.sleep(1000); i++ }
        }
    }

    private fun tick(c: Context) {
        val p = c.getSharedPreferences("j", Context.MODE_PRIVATE)
        val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        if (today != dayKey) { dayKey = today; sent = 0 }
        if (sent >= p.getInt("trade_max", 3)) return
        if (pending != null && System.currentTimeMillis() < pendingUntil) return
        if (Agent.busy) return
        if (System.currentTimeMillis() - lastTradeAt < 10 * 60 * 1000L) return
        val cs = candles(p.getString("trade_tf", "15m") ?: "15m")
        val s = Smc.analyze(cs, p.getInt("trade_rr", 20) / 10.0).sig ?: return
        if (s.key == lastKey) return
        lastKey = s.key
        sent++
        val mode = p.getString("trade_mode", "confirm") ?: "confirm"
        if (mode == "auto" && p.getBoolean("trade_demo_ok", false)) {
            VoiceService.inst?.announce(text(s, false) + " Khud order laga raha hu.")
            execute(c, s)
        } else if (mode == "signal") {
            VoiceService.inst?.announce(text(s, false))
        } else {
            pending = s
            pendingUntil = System.currentTimeMillis() + 90000L
            VoiceService.inst?.announce(text(s, true))
        }
    }

    // "gold kaisa hai" par turant jaanch
    fun now(c: Context): String {
        val p = c.getSharedPreferences("j", Context.MODE_PRIVATE)
        val cs = candles(p.getString("trade_tf", "15m") ?: "15m")
        if (cs.isEmpty()) return "Gold ka price data nahi aa raha, net check karo"
        val res = Smc.analyze(cs, p.getInt("trade_rr", 20) / 10.0)
        val s = res.sig ?: return "Gold abhi " + fmt2(cs.last().c) + " par hai. " + res.note
        lastKey = s.key
        pending = s
        pendingUntil = System.currentTimeMillis() + 90000L
        return text(s, true)
    }

    // Broker app me demo account par order lagata hai (screen padh kar)
    private fun execute(c: Context, s: Signal) {
        val p = c.getSharedPreferences("j", Context.MODE_PRIVATE)
        val app = p.getString("trade_app", "") ?: ""
        val lot = p.getString("trade_lot", "0.01") ?: "0.01"
        if (app.isBlank()) { VoiceService.inst?.announce("Settings me broker app ka naam daalo"); return }
        lastTradeAt = System.currentTimeMillis()
        val goal = "In the " + app + " app on a DEMO account, place a " + s.dir + " market order for XAUUSD (gold) with volume " + lot +
            ", stop loss " + fmt2(s.sl) + " and take profit " + fmt2(s.tp) + ". Open the app, go to the Trade or Quotes tab, open a new order for XAUUSD, " +
            "enter the volume, stop loss and take profit, then tap the " + (if (s.dir == "BUY") "Buy" else "Sell") + " by market button. " +
            "Check first that the account is a demo or trial account."
        Agent.run(c, goal) { r -> VoiceService.inst?.announce(r) }
    }

    // "haan" par
    fun accept(c: Context, s: Signal): String {
        val p = c.getSharedPreferences("j", Context.MODE_PRIVATE)
        val mode = p.getString("trade_mode", "confirm") ?: "confirm"
        val ready = p.getBoolean("trade_demo_ok", false)
        val name = p.getString("trade_app", "") ?: ""
        val line = s.dir + " XAUUSD entry " + fmt2(s.entry) + " SL " + fmt2(s.sl) + " TP " + fmt2(s.tp)
        Toast.makeText(c, line, Toast.LENGTH_LONG).show()
        if (name.isBlank()) return "Settings me broker app ka naam daalo. Levels: " + line
        if (mode != "signal" && ready) {
            execute(c, s)
            return "Theek hai, order laga raha hu. Rokna ho to orb dabao"
        }
        val pm = c.packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val m = list.firstOrNull { it.loadLabel(pm).toString().contains(name, true) } ?: return name + " app nahi mila. Levels: " + line
        c.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(m.activityInfo.packageName, m.activityInfo.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return name + " khol diya. " + (if (s.dir == "BUY") "Buy" else "Sell") + ", stop loss " + fmt2(s.sl) + ", target " + fmt2(s.tp) +
            ". Auto order ke liye Settings me DEMO account wala switch ON karo."
    }
}
