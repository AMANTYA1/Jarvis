package com.jarvis.mine

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.app.usage.UsageStatsManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.CalendarContract
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Settings
import android.provider.Telephony
import android.telecom.TelecomManager
import android.telephony.SmsManager
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

// Naye features: SMS, call, calendar, briefing, location, screen padhna, Instagram/Telegram, notes, screen time...
class Extras(private val c: Context) {
    private val h = Handler(Looper.getMainLooper())
    private var ring: Ringtone? = null

    private fun granted(p: String) = c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun prefs() = c.getSharedPreferences("j", Context.MODE_PRIVATE)

    // ---------- contacts ----------
    fun numberFor(arg: String): String {
        var num = arg.filter { it.isDigit() || it == '+' }
        if (num.length >= 5) return num
        num = ""
        if (!granted(Manifest.permission.READ_CONTACTS)) return ""
        val p = ContactsContract.CommonDataKinds.Phone.NUMBER
        val names = listOf(arg.trim()) + arg.trim().split(" ").filter { it.length > 2 }
        for (n in names) {
            c.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(p),
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", arrayOf("%$n%"), null)?.use {
                if (it.moveToFirst()) num = it.getString(0)
            }
            if (num.isNotEmpty()) break
        }
        return num
    }

    fun nameFor(num: String): String {
        if (num.isBlank() || !granted(Manifest.permission.READ_CONTACTS)) return num
        val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(num))
        try {
            c.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0) ?: num
            }
        } catch (e: Exception) { }
        return num
    }

    // ---------- SMS ----------
    @Suppress("DEPRECATION")
    private fun smsManager(): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java) else SmsManager.getDefault()

    fun sms(name: String, msg: String): String {
        if (msg.isBlank()) return "Kya SMS bhejna hai?"
        if (!granted(Manifest.permission.SEND_SMS)) return "SMS ki permission nahi hai, app me permission do"
        val num = numberFor(name)
        if (num.isEmpty()) return "$name ka number nahi mila"
        return try {
            val sm = smsManager()
            val parts = sm.divideMessage(msg)
            if (parts.size > 1) sm.sendMultipartTextMessage(num, null, parts, null, null)
            else sm.sendTextMessage(num, null, msg, null, null)
            "$name ko SMS bhej diya"
        } catch (e: Exception) { "SMS nahi ja paaya" }
    }

    fun readSms(): String {
        if (!granted(Manifest.permission.READ_SMS)) return "SMS padhne ki permission nahi hai"
        val out = ArrayList<String>()
        try {
            c.contentResolver.query(Telephony.Sms.Inbox.CONTENT_URI,
                arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY), null, null, "date DESC")?.use {
                while (it.moveToNext() && out.size < 3) {
                    out.add(nameFor(it.getString(0) ?: "") + " ne likha: " + (it.getString(1) ?: "").take(150))
                }
            }
        } catch (e: Exception) { return "SMS nahi padh paaya" }
        return if (out.isEmpty()) "Koi SMS nahi mila" else out.joinToString(". ")
    }

    // ---------- calls ----------
    fun answerCall(): String {
        if (!granted(Manifest.permission.ANSWER_PHONE_CALLS)) return "Call uthane ki permission nahi hai"
        return try {
            c.getSystemService(TelecomManager::class.java).acceptRingingCall()
            "Call utha liya"
        } catch (e: Exception) { "Call nahi utha paaya" }
    }

    @Suppress("DEPRECATION")
    fun rejectCall(): String {
        if (Build.VERSION.SDK_INT < 28) return "Is Android version par call kaatna supported nahi hai"
        if (!granted(Manifest.permission.ANSWER_PHONE_CALLS)) return "Call kaatne ki permission nahi hai"
        return try {
            c.getSystemService(TelecomManager::class.java).endCall()
            "Call kaat diya"
        } catch (e: Exception) { "Call nahi kaat paaya" }
    }

    // ---------- calendar ----------
    private fun parseTime(s: String): Long? =
        try { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).parse(s.trim())?.time } catch (e: Exception) { null }

    fun addEvent(whenStr: String, title: String): String {
        if (!granted(Manifest.permission.WRITE_CALENDAR)) return "Calendar ki permission nahi hai, app me permission do"
        val t = parseTime(whenStr) ?: return "Time samajh nahi aaya"
        var calId = -1L
        try {
            c.contentResolver.query(CalendarContract.Calendars.CONTENT_URI, arrayOf(CalendarContract.Calendars._ID),
                CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL + " >= " + CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR,
                null, CalendarContract.Calendars.IS_PRIMARY + " DESC")?.use {
                if (it.moveToFirst()) calId = it.getLong(0)
            }
        } catch (e: Exception) { }
        if (calId < 0) return "Calendar nahi mila, pehle Google Calendar me account jodo"
        val name = title.ifBlank { "Jarvis reminder" }
        val v = ContentValues()
        v.put(CalendarContract.Events.CALENDAR_ID, calId)
        v.put(CalendarContract.Events.TITLE, name)
        v.put(CalendarContract.Events.DTSTART, t)
        v.put(CalendarContract.Events.DTEND, t + 3600000L)
        v.put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
        val uri = try { c.contentResolver.insert(CalendarContract.Events.CONTENT_URI, v) } catch (e: Exception) { null }
            ?: return "Event nahi ban paaya"
        val id = uri.lastPathSegment?.toLongOrNull()
        if (id != null) {
            try {
                val r = ContentValues()
                r.put(CalendarContract.Reminders.EVENT_ID, id)
                r.put(CalendarContract.Reminders.MINUTES, 10)
                r.put(CalendarContract.Reminders.METHOD, CalendarContract.Reminders.METHOD_ALERT)
                c.contentResolver.insert(CalendarContract.Reminders.CONTENT_URI, r)
            } catch (e: Exception) { }
        }
        return "Calendar me add kar diya: $name, " + SimpleDateFormat("d MMM, h:mm a", Locale("en", "IN")).format(Date(t))
    }

    fun todayEvents(): String {
        if (!granted(Manifest.permission.READ_CALENDAR)) return "Calendar padhne ki permission nahi hai"
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        val start = cal.timeInMillis
        val list = ArrayList<Pair<Long, String>>()
        try {
            CalendarContract.Instances.query(c.contentResolver,
                arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN), start, start + 86400000L)?.use {
                while (it.moveToNext()) list.add(Pair(it.getLong(1), it.getString(0) ?: "event"))
            }
        } catch (e: Exception) { return "Calendar nahi padh paaya" }
        if (list.isEmpty()) return "Aaj calendar me kuch nahi hai"
        val f = SimpleDateFormat("h:mm a", Locale("en", "IN"))
        return "Aaj " + list.size + " event hain. " + list.sortedBy { it.first }.take(5).joinToString(". ") { it.second + " " + f.format(Date(it.first)) }
    }

    // ---------- briefing ----------
    private fun batteryPct(): Int = c.getSystemService(BatteryManager::class.java).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)

    fun briefing(): String {
        val sb = StringBuilder("Good morning! ")
        sb.append("Abhi ").append(SimpleDateFormat("h:mm a, EEEE d MMMM", Locale("en", "IN")).format(Date())).append(" ho rahe hain. ")
        sb.append("Battery ").append(batteryPct()).append(" percent hai. ")
        sb.append(todayEvents()).append(". ")
        sb.append(NotifStore.important())
        return sb.toString()
    }

    // ---------- phone dhundhna / location ----------
    fun findPhone(): String {
        return try {
            val am = c.getSystemService(AudioManager::class.java)
            am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            val r = RingtoneManager.getRingtone(c, uri)
            r.audioAttributes = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            if (Build.VERSION.SDK_INT >= 28) r.isLooping = true
            r.play()
            ring = r
            h.postDelayed({ stopRing() }, 25000)
            "Ye raha main! Band karne ke liye Jarvis bas bolo"
        } catch (e: Exception) { "Awaaz nahi bajaa paaya" }
    }

    fun stopRing() {
        try { ring?.stop() } catch (e: Exception) { }
        ring = null
    }

    fun isRinging(): Boolean = try { ring?.isPlaying == true } catch (e: Exception) { false }

    @Suppress("DEPRECATION", "MissingPermission")
    fun where(): String {
        if (!granted(Manifest.permission.ACCESS_FINE_LOCATION) && !granted(Manifest.permission.ACCESS_COARSE_LOCATION))
            return "Location ki permission nahi hai, app me permission do"
        val lm = c.getSystemService(LocationManager::class.java)
        var best: Location? = null
        for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)) {
            try {
                val l = lm.getLastKnownLocation(p)
                val b = best
                if (l != null && (b == null || l.time > b.time)) best = l
            } catch (e: Exception) { }
        }
        val loc = best ?: return "Location abhi nahi mil rahi, GPS ON karke dobara bolo"
        val addr = try {
            Geocoder(c, Locale("en", "IN")).getFromLocation(loc.latitude, loc.longitude, 1)?.firstOrNull()?.getAddressLine(0)
        } catch (e: Exception) { null }
        return if (addr != null) "Phone yahan hai: $addr"
        else "Phone ki location latitude " + "%.4f".format(loc.latitude) + ", longitude " + "%.4f".format(loc.longitude) + " hai"
    }

    // ---------- reminders ----------
    fun remind(whenStr: String, text: String): String {
        val t = parseTime(whenStr) ?: return "Time samajh nahi aaya"
        if (text.isBlank()) return "Kya yaad dilana hai?"
        if (t <= System.currentTimeMillis() + 5000) return "Ye time nikal chuka hai"
        val id = System.currentTimeMillis()
        Cfg.remAdd(prefs(), Reminder(id, t, text))
        ReminderReceiver.schedule(c, id, t, text)
        val f = SimpleDateFormat("d MMM, h:mm a", Locale("en", "IN")).format(Date(t))
        return "Theek hai, $f ko yaad dilaunga: $text"
    }

    fun remindersRead(): String {
        val l = Cfg.rems(prefs()).filter { it.at > System.currentTimeMillis() }
        if (l.isEmpty()) return "Koi reminder nahi hai"
        val f = SimpleDateFormat("d MMM h:mm a", Locale("en", "IN"))
        return "Aapke ${l.size} reminder hain. " + l.take(4).joinToString(". ") { f.format(Date(it.at)) + " ko " + it.text }
    }

    // ---------- kya miss hua ----------
    fun missed(): String {
        val out = ArrayList<String>()
        if (granted(Manifest.permission.READ_CALL_LOG)) {
            try {
                c.contentResolver.query(CallLog.Calls.CONTENT_URI, arrayOf(CallLog.Calls.NUMBER),
                    CallLog.Calls.TYPE + "=? AND " + CallLog.Calls.NEW + "=1", arrayOf(CallLog.Calls.MISSED_TYPE.toString()),
                    CallLog.Calls.DATE + " DESC")?.use {
                    val names = ArrayList<String>()
                    while (it.moveToNext() && names.size < 5) names.add(nameFor(it.getString(0) ?: ""))
                    if (names.isNotEmpty()) out.add("Missed call: " + names.distinct().joinToString(", "))
                }
            } catch (e: Exception) { }
        }
        if (granted(Manifest.permission.READ_SMS)) {
            try {
                c.contentResolver.query(Telephony.Sms.Inbox.CONTENT_URI, arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY),
                    Telephony.Sms.READ + "=0", null, "date DESC")?.use {
                    var n = 0
                    val parts = ArrayList<String>()
                    while (it.moveToNext()) { n++; if (parts.size < 2) parts.add(nameFor(it.getString(0) ?: "") + ": " + (it.getString(1) ?: "").take(60)) }
                    if (n > 0) out.add("$n unread SMS. " + parts.joinToString(". "))
                }
            } catch (e: Exception) { }
        }
        val imp = NotifStore.important()
        if (!imp.startsWith("Koi")) out.add(imp)
        return if (out.isEmpty()) "Kuch bhi miss nahi hua, sab theek hai" else out.joinToString(". ")
    }

    // ---------- SOS ----------
    @Suppress("DEPRECATION", "MissingPermission")
    private fun lastLoc(): Location? {
        if (!granted(Manifest.permission.ACCESS_FINE_LOCATION) && !granted(Manifest.permission.ACCESS_COARSE_LOCATION)) return null
        val lm = c.getSystemService(LocationManager::class.java)
        var best: Location? = null
        for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)) {
            try {
                val l = lm.getLastKnownLocation(p)
                val b = best
                if (l != null && (b == null || l.time > b.time)) best = l
            } catch (e: Exception) { }
        }
        return best
    }

    // Chune hue SOS contacts ko location ke saath SMS bhejta hai aur pehle contact ko call lagata hai
    fun sos(list: List<SosContact>): String {
        if (list.isEmpty()) return "Koi SOS contact nahi chuna hai"
        if (!granted(Manifest.permission.SEND_SMS)) return "SMS ki permission nahi hai, app me permission do"
        val loc = lastLoc()
        val where = if (loc != null) "https://maps.google.com/?q=" + loc.latitude + "," + loc.longitude else "location abhi nahi mili"
        val msg = "EMERGENCY! Mujhe madad chahiye. Meri location: $where . (Jarvis app se SOS)"
        var sent = 0
        for (ct in list) {
            try {
                val sm = smsManager()
                val parts = sm.divideMessage(msg)
                if (parts.size > 1) sm.sendMultipartTextMessage(ct.number, null, parts, null, null)
                else sm.sendTextMessage(ct.number, null, msg, null, null)
                sent++
            } catch (e: Exception) { }
        }
        var calling = false
        if (granted(Manifest.permission.CALL_PHONE)) {
            val first = list[0]
            h.post {
                try {
                    c.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(first.number))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) { }
            }
            calling = true
        }
        return if (sent == 0) "SOS SMS nahi ja paaya"
        else "SOS $sent logon ko bhej diya" + (if (calling) ", " + list[0].name + " ko call laga raha hu" else "")
    }

    // ---------- screen padhna ----------
    fun explainScreen(key: String, screen: String, q: String): String {
        if (key.isEmpty()) return "Pehle app me API key daalo"
        val sys = "You read the text of a phone screen for the user. Answer in short natural Hinglish (Roman script), max 4 sentences. " +
            "Do not read out passwords, OTPs or card numbers; just say they are visible on screen."
        val u = (if (q.isBlank()) "Summarize what is on this screen." else q) + "\n\nSCREEN TEXT:\n" + screen.take(4500)
        val (t, code) = Net.ask(key, sys, u)
        return t ?: Net.errSay(code)
    }

    // ---------- step runner (Accessibility se chalne wale kaam) ----------
    private class Step(val wait: Long, val must: Boolean, val f: () -> Boolean)

    private fun runSteps(steps: List<Step>, i: Int, tries: Int, ok: String, done: (String) -> Unit) {
        if (i >= steps.size) { done(ok); return }
        val s = steps[i]
        h.postDelayed({
            val r = try { s.f() } catch (e: Exception) { false }
            if (r || !s.must) runSteps(steps, i + 1, 0, ok, done)
            else if (tries < 3) runSteps(steps, i, tries + 1, ok, done)
            else done("Ye poora nahi ho paaya, ek baar screen dekh lo")
        }, if (tries == 0) s.wait else 1000L)
    }

    // Instagram / Telegram me message bhejna (WhatsApp jaisa, Accessibility se)
    fun appMsg(app: String, to: String, msg: String, done: (String) -> Unit) {
        val a = JarvisAccess.inst
        if (a == null) { done("Pehle Accessibility ON karo"); return }
        if (to.isBlank() || msg.isBlank()) { done("Kisko aur kya message bhejna hai?"); return }
        val tg = app.contains("tele", true)
        val label = if (tg) "Telegram" else "Instagram"
        val pm = c.packageManager
        val m = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .firstOrNull { it.loadLabel(pm).toString().contains(label, true) }
        if (m == null) { done("$label phone me nahi mila"); return }
        c.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(m.activityInfo.packageName, m.activityInfo.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        val s = ArrayList<Step>()
        if (tg) {
            s.add(Step(3500, true) { a.clickText("Search") })
        } else {
            s.add(Step(4000, true) { a.clickText("Messages") || a.clickText("Message") || a.clickText("Messenger") || a.clickText("Direct") })
            s.add(Step(2500, false) { a.clickText("Search") })
        }
        s.add(Step(1500, true) { a.typeReply(to) })
        s.add(Step(2500, true) { a.clickResult(to) })
        s.add(Step(2500, true) { a.typeReply(msg) })
        s.add(Step(1000, true) { a.clickSend() })
        runSteps(s, 0, 0, "$to ko $label par message bhej diya", done)
    }

    // Reel / short par comment
    fun comment(text: String, done: (String) -> Unit) {
        val a = JarvisAccess.inst
        if (a == null) { done("Pehle Accessibility ON karo"); return }
        val s = listOf(
            Step(0, true) { a.clickComment() },
            Step(1800, true) { a.typeReply(text) },
            Step(900, true) { a.clickPost() }
        )
        runSteps(s, 0, 0, "Comment kar diya", done)
    }

    // Wi-Fi / Bluetooth / hotspot: quick settings tile tap (har phone par pakka nahi)
    fun toggle(what: String, done: (String) -> Unit) {
        val w = what.lowercase()
        val labels: List<String>
        val fallback: String
        val nice: String
        when {
            w.contains("wifi") || w.contains("wi-fi") || w.contains("internet") || w.contains("वाई") -> {
                labels = listOf("Wi-Fi", "WiFi", "Internet"); fallback = Settings.ACTION_WIFI_SETTINGS; nice = "Wi-Fi"
            }
            w.contains("bluetooth") || w.contains("ब्लूटूथ") -> {
                labels = listOf("Bluetooth"); fallback = Settings.ACTION_BLUETOOTH_SETTINGS; nice = "Bluetooth"
            }
            w.contains("hotspot") || w.contains("हॉटस्पॉट") -> {
                labels = listOf("Hotspot", "Mobile Hotspot", "Portable hotspot"); fallback = Settings.ACTION_WIRELESS_SETTINGS; nice = "Hotspot"
            }
            else -> { done("Ye toggle abhi nahi aata"); return }
        }
        val a = JarvisAccess.inst
        if (a == null) { openSettings(fallback); done("Accessibility band hai, $nice ki settings khol di"); return }
        a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
        h.postDelayed({
            var ok = false
            for (l in labels) { if (a.clickText(l)) { ok = true; break } }
            h.postDelayed({
                a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
                if (ok) done("$nice ka tile dabaya, ek baar check kar lena")
                else { openSettings(fallback); done("Tile nahi mila, $nice ki settings khol di") }
            }, 700)
        }, 900)
    }

    private fun openSettings(action: String) {
        try { c.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
    }

    fun see() {
        c.startActivity(Intent(c, CameraActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---------- screen time ----------
    private fun fmt(min: Long): String = if (min >= 60) "${min / 60} ghanta ${min % 60} minute" else "$min minute"

    fun screenTime(app: String): String {
        val usm = c.getSystemService(UsageStatsManager::class.java)
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        val m = try { usm.queryAndAggregateUsageStats(cal.timeInMillis, System.currentTimeMillis()) } catch (e: Exception) { null }
        if (m == null || m.isEmpty()) return "Pehle app me Usage access ON karo"
        val pm = c.packageManager
        val list = ArrayList<Pair<String, Long>>()
        for ((pkg, st) in m) {
            if (pkg == c.packageName || st.totalTimeInForeground < 60000L) continue
            if (pm.getLaunchIntentForPackage(pkg) == null) continue
            val label = try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }
            list.add(Pair(label, st.totalTimeInForeground / 60000L))
        }
        if (app.isNotBlank()) {
            val f = list.firstOrNull { it.first.contains(app, true) }
            return if (f != null) f.first + " aaj " + fmt(f.second) + " chala" else "$app aaj nahi chala"
        }
        if (list.isEmpty()) return "Aaj abhi tak kuch khaas use nahi hua"
        val top = list.sortedByDescending { it.second }.take(5)
        return "Aaj phone " + fmt(list.sumOf { it.second }) + " chala. Sabse zyada: " + top.joinToString(", ") { it.first + " " + fmt(it.second) }
    }

    // ---------- notes ----------
    private fun notes(): JSONArray = try { JSONArray(prefs().getString("notes", "[]") ?: "[]") } catch (e: Exception) { JSONArray() }

    fun noteAdd(t: String): String {
        if (t.isBlank()) return "Kya note karna hai?"
        val a = notes()
        a.put(t.trim())
        prefs().edit().putString("notes", a.toString()).apply()
        return "Note kar liya"
    }

    fun noteRead(): String {
        val a = notes()
        if (a.length() == 0) return "Koi note nahi hai"
        val out = ArrayList<String>()
        for (i in maxOf(0, a.length() - 5) until a.length()) out.add("Note " + (i + 1) + ": " + a.optString(i))
        return out.joinToString(". ")
    }
}
