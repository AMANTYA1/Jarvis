package com.jarvis.mine

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.telephony.TelephonyManager

// Aane wali call par Jarvis bolta hai kiska call hai
class CallReceiver : BroadcastReceiver() {
    companion object {
        private val h = Handler(Looper.getMainLooper())
        private var lastNum = ""
        private var lastAt = 0L
        private var pending: Runnable? = null
    }

    override fun onReceive(ctx: Context, i: Intent) {
        if (i.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        val st = i.getStringExtra(TelephonyManager.EXTRA_STATE)
        pending?.let { h.removeCallbacks(it) }
        pending = null
        if (st != TelephonyManager.EXTRA_STATE_RINGING) return
        @Suppress("DEPRECATION")
        val num = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: ""
        val now = System.currentTimeMillis()
        if (num.isEmpty()) {
            // Android pehle bina number ke broadcast bhejta hai, number aane ka thoda intezar
            val r = Runnable {
                if (System.currentTimeMillis() - lastAt > 8000) {
                    lastAt = System.currentTimeMillis()
                    VoiceService.inst?.incomingCall("")
                }
            }
            pending = r
            h.postDelayed(r, 1500)
            return
        }
        if (num == lastNum && now - lastAt < 8000) return
        lastNum = num
        lastAt = now
        val name = Extras(ctx.applicationContext).nameFor(num)
        VoiceService.inst?.incomingCall(name)
    }
}
