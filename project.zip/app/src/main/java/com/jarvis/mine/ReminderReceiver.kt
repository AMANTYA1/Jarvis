package com.jarvis.mine

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Notification
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

// Reminder ka time aane par bolta hai (Jarvis chalu ho) aur notification bhi dikhata hai
class ReminderReceiver : BroadcastReceiver() {
    companion object {
        private fun pi(c: Context, id: Long, text: String): PendingIntent {
            val i = Intent(c, ReminderReceiver::class.java).putExtra("id", id).putExtra("text", text)
            return PendingIntent.getBroadcast(c, (id % Int.MAX_VALUE).toInt(), i,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }

        fun schedule(c: Context, id: Long, at: Long, text: String) {
            val am = c.getSystemService(AlarmManager::class.java)
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(c, id, text))
        }

        fun cancel(c: Context, id: Long, text: String) {
            try { c.getSystemService(AlarmManager::class.java).cancel(pi(c, id, text)) } catch (e: Exception) { }
        }
    }

    override fun onReceive(c: Context, i: Intent) {
        val id = i.getLongExtra("id", 0L)
        val text = i.getStringExtra("text") ?: return
        Cfg.remRemove(c.getSharedPreferences("j", Context.MODE_PRIVATE), id)
        VoiceService.inst?.announce("Yaad dilana tha: $text")
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis_rem", "Jarvis reminders", NotificationManager.IMPORTANCE_HIGH))
        nm.notify((id % Int.MAX_VALUE).toInt(), Notification.Builder(c, "jarvis_rem")
            .setContentTitle("Jarvis reminder").setContentText(text)
            .setSmallIcon(android.R.drawable.ic_popup_reminder).setAutoCancel(true).build())
    }
}
