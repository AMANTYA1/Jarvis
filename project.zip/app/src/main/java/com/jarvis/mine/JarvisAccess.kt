package com.jarvis.mine

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class Msg(val incoming: Boolean, val text: String)

class JarvisAccess : AccessibilityService() {
    companion object { var inst: JarvisAccess? = null }

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(intent: Intent?): Boolean { inst = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun clickUp(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        while (c != null) {
            if (c.isClickable) return c.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            c = c.parent
        }
        return false
    }

    private fun tapAt(x: Float, y: Float): Boolean {
        val p = Path()
        p.moveTo(x, y)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build()
        return dispatchGesture(g, null, null)
    }

    private fun tapNode(n: AccessibilityNodeInfo): Boolean {
        if (clickUp(n)) return true
        val r = Rect()
        n.getBoundsInScreen(r)
        return tapAt(r.exactCenterX(), r.exactCenterY())
    }

    fun clickText(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(t)) {
            if (clickUp(n)) return true
        }
        return false
    }

    // YouTube search results me pehla (ad/shorts chhod kar) video tap karta hai
    fun playFirstVideo(): Boolean {
        val root = rootInActiveWindow ?: return false
        val pkg = root.packageName?.toString() ?: ""
        if (!pkg.contains("youtube")) return false
        val found = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 25 || found.isNotEmpty()) return
            val d = (n.contentDescription?.toString() ?: "").lowercase()
            if ((d.contains("play video") || d.contains("वीडियो चलाएं") || d.contains("वीडियो चलाएँ")) &&
                !d.contains("sponsored") && !d.contains("shorts") && !d.contains("advert")) {
                found.add(n); return
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        return if (found.isNotEmpty()) tapNode(found[0]) else false
    }

    // Agar video node na mile to screen ke upar-beech me pehle result par tap
    fun tapFirstResultFallback(): Boolean {
        val dm = resources.displayMetrics
        return tapAt(dm.widthPixels * 0.5f, dm.heightPixels * 0.30f)
    }

    // WhatsApp chat me Send button dabata hai
    fun clickSend(): Boolean {
        val root = rootInActiveWindow ?: return false
        for (id in listOf("com.whatsapp:id/send", "com.whatsapp.w4b:id/send")) {
            for (n in root.findAccessibilityNodeInfosByViewId(id)) if (clickUp(n)) return true
        }
        for (t in listOf("Send", "भेजें", "भेजे")) {
            for (n in root.findAccessibilityNodeInfosByText(t)) {
                val d = n.contentDescription?.toString() ?: n.text?.toString() ?: ""
                if (d.equals(t, true) && clickUp(n)) return true
            }
        }
        return false
    }

    // "down" = neeche scroll / agla reel (swipe upar ki taraf), "up" = upar scroll
    fun scroll(dir: String): Boolean {
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val hh = dm.heightPixels.toFloat()
        val up = dir.lowercase() == "up"
        val p = Path()
        p.moveTo(x, if (up) hh * 0.3f else hh * 0.7f)
        p.lineTo(x, if (up) hh * 0.7f else hh * 0.3f)
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 250)).build()
        return dispatchGesture(g, null, null)
    }

    // Jis text box me cursor hai usme text likhta hai
    fun typeText(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val n = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    fun foregroundPkg(): String = rootInActiveWindow?.packageName?.toString() ?: ""

    private fun findEditable(n: AccessibilityNodeInfo?, d: Int = 0): AccessibilityNodeInfo? {
        if (n == null || d > 30) return null
        if (n.isEditable) return n
        for (i in 0 until n.childCount) {
            val r = findEditable(n.getChild(i), d + 1)
            if (r != null) return r
        }
        return null
    }

    private fun isNoise(t: String): Boolean {
        val l = t.lowercase().trim()
        if (Regex("^\\d{1,2}[:.]\\d{2}\\s?([ap]m)?$").matches(l)) return true
        return l in setOf("today", "yesterday", "online", "typing...", "typing…", "type a message", "message",
            "read", "delivered", "sent", "seen", "आज", "कल")
    }

    // Khuli hui chat ke messages padhta hai. incoming = samne wale ka (left side), warna apna (right side)
    fun readChat(): List<Msg>? {
        val root = rootInActiveWindow ?: return null
        val dm = resources.displayMetrics
        val w = dm.widthPixels
        val hh = dm.heightPixels
        val input = findEditable(root) ?: return null
        val ir = Rect()
        input.getBoundsInScreen(ir)
        val inputTop = if (ir.top > hh * 0.4) ir.top else hh
        val items = ArrayList<Triple<Int, Boolean, String>>()
        fun walk(n: AccessibilityNodeInfo?, d: Int) {
            if (n == null || d > 30 || n.isEditable) return
            val t = n.text?.toString()?.trim() ?: ""
            if (t.isNotEmpty() && n.childCount == 0 && n.isVisibleToUser) {
                val r = Rect()
                n.getBoundsInScreen(r)
                if (r.top > hh * 0.10 && r.bottom <= inputTop && !isNoise(t)) {
                    items.add(Triple(r.top, r.left < (w - r.right), t))
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), d + 1)
        }
        walk(root, 0)
        if (items.isEmpty()) return null
        return items.sortedBy { it.first }.map { Msg(it.second, it.third) }
    }

    // Message box me reply likhta hai (bhejne ke liye baad me clickSend())
    fun typeReply(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val input = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root) ?: return false
        input.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
        return input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    // ---------- naye helpers ----------
    private fun findNode(pred: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        var res: AccessibilityNodeInfo? = null
        fun walk(n: AccessibilityNodeInfo?, d: Int) {
            if (n == null || d > 30 || res != null) return
            if (pred(n)) { res = n; return }
            for (i in 0 until n.childCount) walk(n.getChild(i), d + 1)
        }
        walk(root, 0)
        return res
    }

    private fun desc(n: AccessibilityNodeInfo): String = (n.contentDescription?.toString() ?: "").lowercase()

    // Search box me likha text chhod kar, neeche aaye result par tap
    fun clickResult(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(t)) {
            if (n.isEditable) continue
            if (tapNode(n)) return true
        }
        return false
    }

    fun doubleTapCenter(): Boolean {
        val dm = resources.displayMetrics
        val p = Path()
        p.moveTo(dm.widthPixels / 2f, dm.heightPixels / 2f)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 40))
            .addStroke(GestureDescription.StrokeDescription(p, 120, 40)).build()
        return dispatchGesture(g, null, null)
    }

    // Reel / short like: pehle Like button, nahi mila to double tap
    fun like(): Boolean {
        val n = findNode {
            val d = desc(it)
            (d.startsWith("like") || d.contains("like this video")) && !d.contains("dislike") && !d.contains("unlike") && !d.startsWith("liked")
        }
        if (n != null && tapNode(n)) return true
        return doubleTapCenter()
    }

    fun clickComment(): Boolean {
        val n = findNode { desc(it).contains("comment") } ?: return false
        return tapNode(n)
    }

    fun clickPost(): Boolean {
        val root = rootInActiveWindow ?: return false
        for (t in listOf("Post", "Send", "पोस्ट", "भेजें")) {
            for (n in root.findAccessibilityNodeInfosByText(t)) {
                if (n.isEditable) continue
                val d = n.contentDescription?.toString() ?: n.text?.toString() ?: ""
                if (d.equals(t, true) && clickUp(n)) return true
            }
        }
        return false
    }

    fun clickShutter(): Boolean {
        val n = findNode {
            val d = desc(it)
            d.contains("shutter") || d.contains("take photo") || d.contains("take picture") || d == "capture" || d.contains("फ़ोटो") || d.contains("शटर")
        } ?: return false
        return tapNode(n)
    }

    fun clickConfirm(): Boolean {
        val n = findNode {
            val t = (it.text?.toString() ?: "").lowercase()
            val d = desc(it)
            t == "done" || t == "ok" || t == "use photo" || d == "done" || d == "ok" || d == "use photo" || d == "confirm"
        } ?: return false
        return tapNode(n)
    }

    // Screen par dikh rahe saare text ek jagah
    fun screenText(): String {
        val root = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?, d: Int) {
            if (n == null || d > 30 || sb.length > 5000) return
            if (n.isVisibleToUser) {
                val t = n.text?.toString()?.trim() ?: ""
                val cd = n.contentDescription?.toString()?.trim() ?: ""
                if (t.isNotEmpty()) sb.append(t).append('\n')
                else if (cd.isNotEmpty() && n.childCount == 0) sb.append(cd).append('\n')
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), d + 1)
        }
        walk(root, 0)
        return sb.toString()
    }
}
