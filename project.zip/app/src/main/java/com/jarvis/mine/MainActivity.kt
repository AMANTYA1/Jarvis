package com.jarvis.mine

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("j", MODE_PRIVATE)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(40, 80, 40, 40)
        val title = TextView(this)
        title.text = "JARVIS"
        title.textSize = 30f
        root.addView(title)
        val key = EditText(this)
        key.hint = "Gemini API key yahan paste karo"
        key.setText(p.getString("key", ""))
        key.setSingleLine()
        root.addView(key)
        fun btn(t: String, a: () -> Unit) {
            val bt = Button(this)
            bt.text = t
            bt.setOnClickListener { a() }
            root.addView(bt)
        }
        btn("1. Mic / Call / Contacts permission") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS, Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        btn("2. Accessibility ON karo (Jarvis chuno)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("3. Notification access ON karo") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        btn("4. Overlay (display over apps) ON karo") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("5. START Jarvis") {
            p.edit().putString("key", key.text.toString().trim()).apply()
            startForegroundService(Intent(this, VoiceService::class.java))
        }
        btn("STOP Jarvis") { stopService(Intent(this, VoiceService::class.java)) }
        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)
    }
}
