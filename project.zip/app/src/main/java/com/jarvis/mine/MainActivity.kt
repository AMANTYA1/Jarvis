package com.jarvis.mine

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {
    private class Row(val b: Button, val label: String, val ok: () -> Boolean)

    private val rows = ArrayList<Row>()
    private val BG = Color.parseColor("#0A0F1E")
    private val CARD = Color.parseColor("#121A2E")
    private val CYAN = Color.parseColor("#00E5FF")
    private val GREEN = Color.parseColor("#3DDC84")
    private val GRAY = Color.parseColor("#8A94A8")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(fill: Int, stroke: Int, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.setStroke(dp(1), stroke)
        g.cornerRadius = dp(r).toFloat()
        return g
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        val p = getSharedPreferences("j", MODE_PRIVATE)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setBackgroundColor(BG)
        root.setPadding(dp(20), dp(40), dp(20), dp(32))

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_fg)
        root.addView(logo, LinearLayout.LayoutParams(dp(150), dp(150)))

        val title = TextView(this)
        title.text = "JARVIS"
        title.textSize = 32f
        title.setTextColor(CYAN)
        title.typeface = Typeface.DEFAULT_BOLD
        title.letterSpacing = 0.3f
        title.gravity = Gravity.CENTER
        root.addView(title)

        val sub = TextView(this)
        sub.text = "Tera apna voice assistant"
        sub.setTextColor(GRAY)
        sub.textSize = 14f
        sub.gravity = Gravity.CENTER
        root.addView(sub)

        val key = EditText(this)
        key.hint = "Gemini API key yahan paste karo"
        key.setHintTextColor(GRAY)
        key.setTextColor(Color.WHITE)
        key.setText(p.getString("key", ""))
        key.setSingleLine()
        key.setPadding(dp(16), dp(14), dp(16), dp(14))
        key.background = shape(CARD, Color.parseColor("#3300E5FF"), 14)
        val klp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        klp.topMargin = dp(28)
        root.addView(key, klp)

        fun mk(label: String, ok: (() -> Boolean)?, click: () -> Unit): Button {
            val bt = Button(this)
            bt.text = label
            bt.isAllCaps = false
            bt.textSize = 15f
            bt.setTextColor(Color.WHITE)
            bt.background = shape(CARD, Color.parseColor("#3300E5FF"), 14)
            bt.setOnClickListener { click() }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54))
            lp.topMargin = dp(10)
            root.addView(bt, lp)
            if (ok != null) rows.add(Row(bt, label, ok))
            return bt
        }

        val keyStatus = TextView(this)
        keyStatus.textSize = 13f
        keyStatus.setTextColor(GRAY)
        keyStatus.gravity = Gravity.CENTER
        mk("Key check karo", null) { checkKey(key.text.toString().trim(), keyStatus) }
        root.addView(keyStatus)

        mk("1.  Mic / Call / Contacts permission",
            { checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED }) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS, Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        mk("2.  Accessibility ON karo", { JarvisAccess.inst != null }) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        mk("3.  Notification access ON karo",
            { Settings.Secure.getString(contentResolver, "enabled_notification_listeners")?.contains(packageName) == true }) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        mk("4.  Overlay (orb) ON karo", { Settings.canDrawOverlays(this) }) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }

        val start = mk("START JARVIS", null) {
            p.edit().putString("key", key.text.toString().trim()).apply()
            startForegroundService(Intent(this, VoiceService::class.java))
            Toast.makeText(this, "Jarvis chalu. Bolo: Jarvis ...", Toast.LENGTH_SHORT).show()
        }
        start.background = shape(CYAN, CYAN, 27)
        start.setTextColor(BG)
        start.typeface = Typeface.DEFAULT_BOLD

        val stop = mk("STOP", null) { stopService(Intent(this, VoiceService::class.java)) }
        stop.background = shape(BG, Color.parseColor("#FF5C5C"), 27)
        stop.setTextColor(Color.parseColor("#FF5C5C"))

        val foot = TextView(this)
        foot.text = "API key kisi ko mat dikhana"
        foot.setTextColor(GRAY)
        foot.textSize = 12f
        foot.gravity = Gravity.CENTER
        val flp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        flp.topMargin = dp(18)
        root.addView(foot, flp)

        val sv = ScrollView(this)
        sv.setBackgroundColor(BG)
        sv.isFillViewport = true
        sv.addView(root)
        setContentView(sv)
    }

    private fun checkKey(k: String, out: TextView) {
        val red = Color.parseColor("#FF5C5C")
        if (k.isEmpty()) { out.text = "Pehle key paste karo"; out.setTextColor(red); return }
        out.text = "Check ho raha hai..."
        out.setTextColor(GRAY)
        Thread {
            var msg = ""
            var good = false
            try {
                val body = "{\"contents\":[{\"parts\":[{\"text\":\"Reply with only: OK\"}]}]}"
                val c = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent")
                    .openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.doOutput = true
                c.connectTimeout = 15000
                c.readTimeout = 30000
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("X-goog-api-key", k)
                c.outputStream.use { it.write(body.toByteArray()) }
                val code = c.responseCode
                val txt = (if (code < 400) c.inputStream else c.errorStream).bufferedReader().readText()
                if (code < 400) {
                    good = true
                    msg = "✓ Key sahi hai, Gemini chal raha hai"
                } else {
                    val why = when (code) {
                        400 -> "Key galat lag rahi hai (400)"
                        403 -> "Key ko permission nahi hai (403)"
                        429 -> "Limit khatam, thodi der baad try karo (429)"
                        else -> "Error $code"
                    }
                    msg = why + "\n" + txt.take(150)
                }
            } catch (e: Exception) {
                msg = "Net/connection me dikkat: " + e.javaClass.simpleName
            }
            runOnUiThread {
                out.text = msg
                out.setTextColor(if (good) GREEN else red)
            }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        for (r in rows) {
            val ok = r.ok()
            r.b.text = if (ok) "✓  " + r.label else r.label
            r.b.setTextColor(if (ok) GREEN else Color.WHITE)
            r.b.background = shape(CARD, if (ok) GREEN else Color.parseColor("#3300E5FF"), 14)
        }
    }
}
