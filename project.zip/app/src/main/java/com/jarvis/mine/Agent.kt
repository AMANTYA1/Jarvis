package com.jarvis.mine

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import org.json.JSONObject

// Screen padh kar ek-ek step me kaam karta hai (trading order ke liye)
object Agent {
    @Volatile var stop = false
    @Volatile var busy = false

    private val SYS = """You control an Android phone through accessibility to place a trade in a trading app. Each turn you get the GOAL, ACTIONS DONE so far, and the CURRENT SCREEN as numbered elements like [3] button "Buy". Reply ONLY with JSON: {"action":"...","index":0,"text":"","app":"","dir":"","say":""}. Actions: open_app (app = app name), click (index), type (index of an input field, text = the value to enter), enter, scroll (dir = up or down), back, home, wait, done (say = short Hinglish summary), fail (say = short Hinglish reason). Rules: one action per turn. If the screen did not change, try the next sensible action. Only work on a DEMO or trial account: if the screen shows a real or live account, or you cannot tell, use fail. Never open deposit, withdraw, transfer or payment pages. Enter the exact numbers from the GOAL. After tapping the final Buy or Sell button and seeing a confirmation or the new position, use done."""

    private fun parse(t: String): JSONObject? {
        val a = t.indexOf('{')
        val b = t.lastIndexOf('}')
        if (a < 0 || b <= a) return null
        return try { JSONObject(t.substring(a, b + 1)) } catch (e: Exception) { null }
    }

    private fun openApp(c: Context, name: String): Boolean {
        val pm = c.packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val m = list.firstOrNull { it.loadLabel(pm).toString().contains(name, true) } ?: return false
        c.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(m.activityInfo.packageName, m.activityInfo.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }

    fun run(c: Context, goal: String, done: (String) -> Unit) {
        if (busy) { done("Pehle wala kaam abhi chal raha hai"); return }
        busy = true
        stop = false
        val app = c.applicationContext
        Thread {
            var say = "Kuch gadbad hui"
            try { say = loop(app, goal) } catch (e: Exception) { }
            busy = false
            done(say)
        }.start()
    }

    private fun loop(c: Context, goal: String): String {
        val key = c.getSharedPreferences("j", Context.MODE_PRIVATE).getString("key", "") ?: ""
        val log = ArrayList<String>()
        var lastSig = ""
        var same = 0
        var bad = 0
        if (JarvisAccess.inst == null) return "Pehle Accessibility ON karo"
        for (step in 1..30) {
            if (stop) return "Ruk gaya"
            val acc = JarvisAccess.inst ?: return "Accessibility band ho gayi"
            val screen = acc.aDump()
            val prompt = "GOAL: " + goal + "\nACTIONS DONE:\n" + log.takeLast(10).joinToString("\n") + "\nCURRENT SCREEN:\n" + screen
            val (txt, code) = Net.ask(key, SYS, prompt, null, 25)
            if (txt == null) return Net.errSay(code)
            val r = parse(txt)
            if (r == null) {
                bad++
                if (bad >= 3) return "Jawab samajh nahi aaya"
                continue
            }
            val a = r.optString("action")
            val idx = r.optInt("index", -1)
            val sig = a + idx + r.optString("text") + r.optString("app") + r.optString("dir")
            if (sig == lastSig) same++ else { same = 0; lastSig = sig }
            if (same >= 3) return "Ye step nahi ho pa raha, main ruk gaya"
            when (a) {
                "open_app" -> {
                    val nm = r.optString("app")
                    val ok = openApp(c, nm)
                    log.add("open_app " + nm + (if (ok) " ok" else " not found"))
                    Thread.sleep(2500)
                }
                "click" -> {
                    val lb = acc.aLabel(idx)
                    val ok = acc.aClick(idx)
                    log.add("click [" + idx + "] " + lb + (if (ok) " ok" else " failed"))
                    Thread.sleep(1300)
                }
                "type" -> {
                    val tx = r.optString("text")
                    val ok = acc.aType(idx, tx)
                    log.add("type [" + idx + "] " + tx + (if (ok) " ok" else " failed"))
                    Thread.sleep(800)
                }
                "enter" -> {
                    log.add("enter " + (if (acc.aEnter()) "ok" else "failed"))
                    Thread.sleep(1200)
                }
                "scroll" -> {
                    acc.aSwipe(r.optString("dir"))
                    log.add("scroll " + r.optString("dir"))
                    Thread.sleep(900)
                }
                "back" -> { acc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK); log.add("back"); Thread.sleep(900) }
                "home" -> { acc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME); log.add("home"); Thread.sleep(900) }
                "wait" -> { log.add("wait"); Thread.sleep(1500) }
                "done" -> return r.optString("say").ifEmpty { "Ho gaya" }
                "fail" -> return r.optString("say").ifEmpty { "Nahi ho paya" }
                else -> log.add("unknown action " + a)
            }
        }
        return "Itna kar paya, baaki aap dekh lo"
    }
}
