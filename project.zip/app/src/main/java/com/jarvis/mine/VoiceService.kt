package com.jarvis.mine

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.app.SearchManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.BatteryManager
import android.provider.AlarmClock
import android.view.KeyEvent
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.ContactsContract
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class VoiceService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speaking = false
    private var commandMode = false
    private var running = false
    private var listening = false
    private var processing = false
    private var lastStart = 0L
    private var sessionUntil = 0L
    private val SESSION_MS = 30000L
    private val hist = ArrayList<Pair<String, String>>()
    private var orbBg: GradientDrawable? = null
    private val endWords = setOf("bas", "bas karo", "bas itna hi", "ruko", "bye", "ok bye", "thanks", "thank you",
        "ok thanks", "dhanyawad", "shukriya", "बस", "बस करो", "बस इतना ही", "रुको", "बाय", "थैंक्यू", "थैंक यू",
        "धन्यवाद", "शुक्रिया", "ठीक है बस")
    private val speakTimeout = Runnable { if (speaking) { speaking = false; listen() } }
    private var wm: WindowManager? = null
    private var orb: TextView? = null
    private val wake = listOf("jarvis", "jarvish", "jaarvis", "जार्विस", "जारविस", "जर्विस", "जारवीस", "जार्विश", "जरविस", "जारवि", "जार्वि")

    private var chatMode = false
    private var chatPkg = ""
    private var chatBusy = false
    private var lastChatKey = ""
    private var lastSent = ""
    private var chatActive = 0L

    private val chatLoop = object : Runnable {
        override fun run() {
            if (!running || !chatMode) return
            if (System.currentTimeMillis() - chatActive > 20 * 60 * 1000L) {
                chatMode = false; updateOrb()
                announce("Chat me 20 minute se kuch nahi hua, main baat karna band kar raha hu")
                return
            }
            try { chatTick() } catch (e: Exception) { chatBusy = false }
            h.postDelayed(this, 2500)
        }
    }

    private fun chatTick() {
        if (chatBusy) return
        val a = JarvisAccess.inst ?: return
        if (a.foregroundPkg() != chatPkg) return
        val msgs = a.readChat() ?: return
        val last = msgs.last()
        if (!last.incoming || last.text == lastSent) return
        val k = msgs.size.toString() + "|" + last.text
        if (k == lastChatKey) return
        lastChatKey = k
        chatBusy = true
        chatActive = System.currentTimeMillis()
        val apiKey = getSharedPreferences("j", MODE_PRIVATE).getString("key", "") ?: ""
        val convo = msgs.takeLast(12).joinToString("\n") { (if (it.incoming) "THEM: " else "OWNER: ") + it.text }
        Thread {
            val r = if (apiKey.isEmpty()) null else AutoReply.generateChat(apiKey, convo)
            h.post { chatReply(r) }
        }.start()
    }

    private fun chatReply(r: JSONObject?) {
        val reply = r?.optString("reply")?.trim() ?: ""
        if (r?.optBoolean("escalate") == true) announce("Chat me kuch zaroori pucha gaya, dekh lo")
        if (!chatMode || reply.isEmpty() || !AutoReply.allowed("screen")) { chatBusy = false; return }
        h.postDelayed({
            val a = JarvisAccess.inst
            if (chatMode && a != null && a.foregroundPkg() == chatPkg && a.typeReply(reply)) {
                lastSent = reply
                h.postDelayed({
                    a.clickSend()
                    AutoReply.addLog("Chat me reply diya: $reply")
                    chatActive = System.currentTimeMillis()
                    chatBusy = false
                }, 800)
            } else chatBusy = false
        }, 2000L + (Math.random() * 2500).toLong())
    }

    private fun startChat(style: String): String {
        val a = JarvisAccess.inst ?: return "Pehle Accessibility ON karo"
        val pkg = a.foregroundPkg()
        if (pkg.isEmpty() || pkg == packageName) return "Pehle woh chat kholo jisme baat karni hai"
        if (style.isNotBlank()) AutoReply.style = style
        chatPkg = pkg; lastChatKey = ""; lastSent = ""; chatBusy = false
        chatActive = System.currentTimeMillis()
        chatMode = true
        h.removeCallbacks(chatLoop)
        h.postDelayed(chatLoop, 1500)
        updateOrb()
        return "Ji, ab main aapki taraf se baat karta hu. Rokna ho to bolo Jarvis bas karo"
    }

    private fun stopChat() {
        chatMode = false
        h.removeCallbacks(chatLoop)
        updateOrb()
    }

    private var vmNum = ""
    private var vmName = ""
    private var vmFile: File? = null

    companion object { var inst: VoiceService? = null }

    override fun onBind(i: Intent?): IBinder? = null

    // Auto-reply wagairah se aane wali suchna (zaroori ho to bolta hai, warna toast)
    fun announce(t: String) {
        h.post {
            if (!speaking && !processing) speak(t) else Toast.makeText(this, t, Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate() {
        super.onCreate()
        inst = this
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "jarvis").setContentTitle("Jarvis sun raha hai")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        tts = TextToSpeech(this) { s ->
            if (s == TextToSpeech.SUCCESS) { tts?.language = Locale("hi", "IN"); ttsReady = true }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) {
                if (id == "vm") { h.post { shareVoice() }; return }
                h.post { speaking = false; if (inSession()) keepSession(); listen() }
            }
            @Deprecated("x") override fun onError(id: String?) {
                if (id == "vm") { h.post { processing = false; speak("Voice banane me dikkat aayi") }; return }
                h.post { speaking = false; listen() }
            }
        })
        running = true
        showOrb()
        h.postDelayed({ listen() }, 800)
        h.postDelayed(watchdog, 3000)
    }

    private val watchdog = object : Runnable {
        override fun run() {
            if (!running) return
            if (listening && System.currentTimeMillis() - lastStart > 15000) { sr?.cancel(); listening = false }
            if (!listening && !speaking && !processing) listen()
            updateOrb()
            h.postDelayed(this, 3000)
        }
    }

    private fun showOrb() {
        if (!Settings.canDrawOverlays(this)) return
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val t = TextView(this)
        t.text = "J"
        t.gravity = Gravity.CENTER
        t.setTextColor(Color.WHITE)
        t.textSize = 11f
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(Color.parseColor("#CC00B8FF"))
        t.background = bg
        orbBg = bg
        t.setOnClickListener { keepSession(); speak("Ji, boliye") }
        val sz = (30 * resources.displayMetrics.density).toInt()
        val lp = WindowManager.LayoutParams(sz, sz, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.END
        lp.x = 20; lp.y = 300
        wm?.addView(t, lp)
        orb = t
    }

    private fun inSession() = System.currentTimeMillis() < sessionUntil

    private fun keepSession() { sessionUntil = System.currentTimeMillis() + SESSION_MS; updateOrb() }

    private fun endSession() { sessionUntil = 0L; updateOrb() }

    private fun updateOrb() {
        orbBg?.setColor(Color.parseColor(if (chatMode) "#CCFF9800" else if (inSession()) "#CC3DDC84" else "#CC00B8FF"))
    }

    private fun speak(text: String) {
        sr?.cancel()
        listening = false
        if (!ttsReady || text.isBlank()) { speaking = false; h.postDelayed({ listen() }, 200); return }
        speaking = true
        val r = tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u")
        if (r != TextToSpeech.SUCCESS) { speaking = false; h.postDelayed({ listen() }, 200); return }
        h.removeCallbacks(speakTimeout)
        h.postDelayed(speakTimeout, 4000L + text.length * 120L)
    }

    private fun listen() {
        if (!running || speaking || processing || listening) return
        if (sr == null) {
            sr = SpeechRecognizer.createSpeechRecognizer(this)
            sr?.setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    listening = false
                    val l = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    handle(l ?: ArrayList())
                }
                override fun onError(e: Int) {
                    listening = false
                    h.postDelayed({ listen() }, if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 500L else 100L)
                }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        i.putExtra("android.speech.extra.SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS", 1200L)
        i.putExtra("android.speech.extra.SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS", 1000L)
        listening = true
        lastStart = System.currentTimeMillis()
        try { sr?.startListening(i) } catch (e: Exception) { listening = false }
    }

    private fun stripWake(t: String): String {
        val low = t.lowercase()
        for (w in wake) {
            val i = low.indexOf(w)
            if (i >= 0) return t.substring(i + w.length).trim()
        }
        return t.trim()
    }

    private fun hasWake(t: String): Boolean {
        val low = t.lowercase()
        return wake.any { low.contains(it) }
    }

    private fun handle(list: List<String>) {
        if (list.isEmpty()) { listen(); return }
        // Session chalu hai: bina "Jarvis" bole seedha command lo
        if (inSession() || commandMode) {
            commandMode = false
            val raw = list[0]
            val cmd = if (hasWake(raw)) stripWake(raw) else raw.trim()
            if (cmd.isEmpty()) { keepSession(); speak("Ji, boliye"); return }
            val norm = cmd.lowercase().trim(' ', '.', '!', '?', ',')
            if (norm in endWords) { endSession(); speak("Theek hai, jab zarurat ho Jarvis bolna"); return }
            keepSession()
            process(cmd)
            return
        }
        for (t in list) {
            if (hasWake(t)) {
                val cmd = stripWake(t)
                keepSession()
                if (cmd.isEmpty()) speak("Ji, boliye") else process(cmd)
                return
            }
        }
        listen()
    }

    private fun process(cmd: String) {
        processing = true
        Thread {
            val res = ask(cmd)
            h.post { act(res) }
        }.start()
    }

    private fun ask(cmd: String): JSONObject {
        val key = getSharedPreferences("j", MODE_PRIVATE).getString("key", "") ?: ""
        if (key.isEmpty()) return JSONObject().put("action", "none").put("say", "Pehle app me API key daalo")
        val sys = "You are Jarvis, a warm, friendly Hinglish voice assistant on the user's Android phone. " +
            "Reply ONLY with JSON: " +
            "{\"action\":\"<action>\",\"arg\":\"string\",\"text\":\"string\",\"say\":\"short Hinglish reply\"}. " +
            "Actions: open_app (arg=app name) | call (arg=contact name or number) | click (arg=visible text to tap) | back | home | " +
            "youtube (arg=song or video search query, it auto-plays) | " +
            "whatsapp (arg=contact name in ENGLISH/Roman letters as saved in phone, or a number; text=message to send) | " +
            "voice_msg (send a WhatsApp VOICE message in Jarvis's voice: arg=contact in Roman letters, text=what to say, written in Devanagari Hindi, English words may stay Roman) | " +
            "autochat (Jarvis chats on WhatsApp on the user's behalf and auto-replies to that person's incoming messages: arg=contact name in Roman letters, or \"all\" for everyone; text=optional tone like pyar se, funny, formal) | " +
            "autochat_off (stop all auto replies) | autochat_log (tell what auto replies were sent) | " +
            "chat_takeover (the user is ON a chat screen in any app such as WhatsApp or Instagram and says things like 'Jarvis baat karo tum' or 'mere side se reply karo': Jarvis reads the open chat and keeps replying there as the user until told to stop; text=optional tone) | " +
            "chat_stop (stop replying on the user's behalf in the open chat) | " +
            "media (arg=play|pause|next|prev for the playing music/video) | volume (arg=up|down|mute or a number 0-100) | " +
            "flash (arg=on|off torch) | alarm (arg=24h time HH:MM, text=label) | timer (arg=seconds as number) | " +
            "system (arg=recents|screenshot|lock|quick_settings|notifications_panel) | scroll (arg=up|down; also use down for next reel/short) | " +
            "type (arg=text to type in the focused text box) | battery | time | maps (arg=place to navigate to) | search (arg=google query) | " +
            "notifications (read recent notifications) | none (just answer in say) | " +
            "ignore (background noise, TV or someone else talking, not addressed to you; say must be empty). " +
            "For whatsapp: if the user dictated the exact message send it as is with spelling fixed. If they gave no message, or asked for " +
            "something nice/sweet/pyara, YOU write a short (1-2 lines), warm, natural Hinglish message in Roman script as if the user is sending it, " +
            "matching the relationship (mummy, friend, bhai, etc.); a heart or smiley emoji is fine. Never write abusive, threatening or deceptive text. " +
            "Keep say short and natural, in Hinglish, like a friendly assistant."
        val contents = JSONArray()
        for ((role, txt) in hist.takeLast(6)) {
            contents.put(JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", txt))))
        }
        contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", cmd))))
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        return try {
            val (code, txt, _) = Net.gemini(key, body.toString())
            if (code >= 400) {
                return JSONObject().put("action", "none").put("say", "API key me dikkat hai")
                    .put("err", "HTTP $code: " + txt.take(250))
            }
            var out = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text").trim()
            if (out.startsWith("[")) out = JSONArray(out).getJSONObject(0).toString()
            val r = JSONObject(out)
            hist.add(Pair("user", cmd))
            hist.add(Pair("model", out))
            while (hist.size > 12) hist.removeAt(0)
            r
        } catch (e: Exception) {
            JSONObject().put("action", "none").put("say", "Net me dikkat hai").put("err", e.toString().take(250))
        }
    }

    private fun act(o: JSONObject) {
        processing = false
        if (o.has("err")) Toast.makeText(this, o.optString("err"), Toast.LENGTH_LONG).show()
        val a = o.optString("action"); val arg = o.optString("arg"); var say = o.optString("say")
        val text = o.optString("text")
        var silent = false
        when (a) {
            "ignore" -> { listen(); return }
            "open_app" -> if (!openApp(arg)) say = "$arg nahi mila"
            "call" -> if (!call(arg)) say = "$arg ka number nahi mila"
            "click" -> if (JarvisAccess.inst?.clickText(arg) != true) say = "Screen par $arg nahi dikha, ya Accessibility band hai"
            "back" -> JarvisAccess.inst?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            "home" -> JarvisAccess.inst?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            "youtube" -> {
                openYoutube(arg)
                processing = true
                h.postDelayed({ autoPlay(0) }, 3000)
                if (say.isBlank()) say = "Ji, $arg laga raha hu"
            }
            "whatsapp" -> {
                val r = whatsapp(arg, text)
                if (r == null) { silent = true } else { say = r }
            }
            "voice_msg" -> {
                val r = voiceMsg(arg, text)
                if (r == null) { silent = true } else { say = r }
            }
            "autochat" -> {
                val who = arg.trim()
                if (who.equals("all", true) || who.equals("sabko", true)) AutoReply.all = true
                else if (who.isNotEmpty()) AutoReply.chats.add(who.lowercase())
                if (text.isNotBlank()) AutoReply.style = text
                if (say.isBlank()) say = "Theek hai, $who se main baat karunga"
            }
            "autochat_off" -> {
                AutoReply.all = false; AutoReply.chats.clear()
                if (say.isBlank()) say = "Auto reply band kar diya"
            }
            "autochat_log" -> say = AutoReply.summary()
            "chat_takeover" -> say = startChat(text)
            "chat_stop" -> { stopChat(); if (say.isBlank()) say = "Theek hai, ab main baat nahi karunga" }
            "media" -> mediaKey(arg)
            "volume" -> volume(arg)
            "flash" -> if (!flash(arg)) say = "Torch nahi chal paayi"
            "alarm" -> if (!setAlarm(arg, text)) say = "Alarm ka time samajh nahi aaya"
            "timer" -> if (!setTimer(arg)) say = "Timer ka time samajh nahi aaya"
            "system" -> if (!system(arg)) say = "Ye abhi nahi ho paaya, Accessibility check karo"
            "scroll" -> if (JarvisAccess.inst?.scroll(arg) != true) say = "Scroll nahi ho paaya, Accessibility check karo"
            "type" -> if (JarvisAccess.inst?.typeText(arg) != true) say = "Text box select nahi hai"
            "battery" -> say = battery()
            "time" -> say = "Abhi " + SimpleDateFormat("h:mm a, EEEE d MMMM", Locale("en", "IN")).format(Date()) + " ho rahe hain"
            "maps" -> navigate(arg)
            "search" -> startActivity(Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.google.com/search?q=" + Uri.encode(arg))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "notifications" -> say = NotifStore.summary()
        }
        keepSession()
        if (!silent) speak(if (say.isBlank()) "Ho gaya" else say)
    }

    private fun openYoutube(q: String) {
        val uri = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))
        val i = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(Intent(i).setPackage("com.google.android.youtube")) }
        catch (e: Exception) { startActivity(i) }
    }

    // YouTube khulne ke baad pehla video khud tap karta hai (retry ke saath)
    private fun autoPlay(tries: Int) {
        if (!running) return
        val a = JarvisAccess.inst
        if (a == null) {
            processing = false
            Toast.makeText(this, "Accessibility ON karo, tabhi gana khud chalega", Toast.LENGTH_LONG).show()
            return
        }
        if (a.playFirstVideo()) { processing = false; return }
        if (tries >= 8) { a.tapFirstResultFallback(); processing = false; return }
        h.postDelayed({ autoPlay(tries + 1) }, 1000)
    }

    private fun findNumber(arg: String): String {
        var num = arg.filter { it.isDigit() || it == '+' }
        if (num.length >= 5) return num
        num = ""
        val P = ContactsContract.CommonDataKinds.Phone.NUMBER
        val names = listOf(arg.trim()) + arg.trim().split(" ").filter { it.length > 2 }
        for (n in names) {
            contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(P),
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", arrayOf("%$n%"), null)?.use {
                if (it.moveToFirst()) num = it.getString(0)
            }
            if (num.isNotEmpty()) break
        }
        return num
    }

    // return null => result baad me khud bolega; warna turant bolne wala text
    private fun whatsapp(name: String, msg: String): String? {
        if (msg.isBlank()) return "Kya message bhejna hai?"
        val num = waNumber(name)
        if (num.isEmpty()) return "$name ka number nahi mila"
        val uri = Uri.parse("https://wa.me/$num?text=" + Uri.encode(msg))
        var ok = false
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                ok = true; break
            } catch (e: Exception) { }
        }
        if (!ok) return "WhatsApp nahi mila"
        processing = true
        h.postDelayed({ sendWa(name, 0, "$name ko message bhej diya") }, 2500)
        return null
    }

    private fun waNumber(name: String): String {
        var num = findNumber(name).filter { it.isDigit() }
        if (num.length == 11 && num.startsWith("0")) num = num.substring(1)
        if (num.length == 10) num = "91$num"
        return num
    }

    // Jarvis ki awaaz me voice file banata hai, phir WhatsApp me bhejta hai
    private fun voiceMsg(name: String, msg: String): String? {
        if (msg.isBlank()) return "Voice me kya bolna hai?"
        val num = waNumber(name)
        if (num.isEmpty()) return "$name ka number nahi mila"
        if (!ttsReady) return "Awaaz abhi ready nahi hai"
        val dir = File(cacheDir, "voice")
        dir.mkdirs()
        val f = File(dir, "jarvis_voice.wav")
        vmNum = num; vmName = name; vmFile = f
        processing = true
        sr?.cancel(); listening = false
        val r = tts?.synthesizeToFile(msg, Bundle(), f, "vm")
        if (r != TextToSpeech.SUCCESS) { processing = false; return "Voice banane me dikkat aayi" }
        return null
    }

    private fun shareVoice() {
        val f = vmFile
        if (f == null || !f.exists()) { processing = false; speak("Voice file nahi bani"); return }
        val uri = FileProvider.getUriForFile(this, "$packageName.fp", f)
        var ok = false
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            try {
                grantUriPermission(pkg, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                val i = Intent(Intent.ACTION_SEND).setType("audio/*")
                    .putExtra(Intent.EXTRA_STREAM, uri)
                    .putExtra("jid", "$vmNum@s.whatsapp.net")
                    .setPackage(pkg)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(i)
                ok = true; break
            } catch (e: Exception) { }
        }
        if (!ok) { processing = false; speak("WhatsApp nahi mila"); return }
        h.postDelayed({ sendWa(vmName, 0, "$vmName ko voice message bhej diya") }, 3000)
    }

    private fun mediaKey(arg: String) {
        val code = when (arg.lowercase()) {
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "prev", "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        val am = getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun volume(arg: String) {
        val am = getSystemService(AudioManager::class.java)
        val st = AudioManager.STREAM_MUSIC
        val n = arg.filter { it.isDigit() }.toIntOrNull()
        when {
            n != null -> am.setStreamVolume(st, am.getStreamMaxVolume(st) * n.coerceIn(0, 100) / 100, AudioManager.FLAG_SHOW_UI)
            arg.lowercase() == "up" -> am.adjustStreamVolume(st, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            arg.lowercase() == "down" -> am.adjustStreamVolume(st, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            arg.lowercase() == "mute" -> am.setStreamVolume(st, 0, AudioManager.FLAG_SHOW_UI)
        }
    }

    private fun flash(arg: String): Boolean {
        return try {
            val cm = getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return false
            cm.setTorchMode(id, arg.lowercase() == "on")
            true
        } catch (e: Exception) { false }
    }

    private fun setAlarm(arg: String, label: String): Boolean {
        val p = arg.split(":")
        val hh = p.getOrNull(0)?.trim()?.toIntOrNull() ?: return false
        val mm = p.getOrNull(1)?.trim()?.toIntOrNull() ?: 0
        return try {
            startActivity(Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, hh).putExtra(AlarmClock.EXTRA_MINUTES, mm)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label.ifBlank { "Jarvis alarm" })
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        } catch (e: Exception) { false }
    }

    private fun setTimer(arg: String): Boolean {
        val sec = arg.filter { it.isDigit() }.toIntOrNull() ?: return false
        return try {
            startActivity(Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, sec)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        } catch (e: Exception) { false }
    }

    private fun system(arg: String): Boolean {
        val a = JarvisAccess.inst ?: return false
        return when (arg.lowercase()) {
            "recents" -> a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
            "quick_settings" -> a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
            "notifications_panel" -> a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            "screenshot" -> Build.VERSION.SDK_INT >= 28 && a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
            "lock" -> Build.VERSION.SDK_INT >= 28 && a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
            else -> false
        }
    }

    private fun battery(): String {
        val bm = getSystemService(BatteryManager::class.java)
        return "Battery " + bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) + " percent hai"
    }

    private fun navigate(place: String) {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(place)))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(Intent(i).setPackage("com.google.android.apps.maps")) }
        catch (e: Exception) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(place)))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun sendWa(name: String, tries: Int, okMsg: String) {
        if (!running) return
        val a = JarvisAccess.inst
        if (a == null) {
            processing = false
            speak("Accessibility ON karo, tabhi main send daba paunga")
            return
        }
        if (a.clickSend()) {
            processing = false
            speak(okMsg)
            return
        }
        if (tries >= 8) {
            processing = false
            speak("Send button nahi mila, message ready hai, ek baar khud daba do")
            return
        }
        h.postDelayed({ sendWa(name, tries + 1, okMsg) }, 1000)
    }

    private fun openApp(name: String): Boolean {
        val pm = packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val m = list.firstOrNull { it.loadLabel(pm).toString().contains(name, true) } ?: return false
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(m.activityInfo.packageName, m.activityInfo.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        return true
    }

    private fun call(arg: String): Boolean {
        val num = findNumber(arg)
        if (num.isEmpty()) return false
        startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }

    override fun onDestroy() {
        inst = null
        running = false
        h.removeCallbacksAndMessages(null)
        sr?.destroy()
        tts?.shutdown()
        orb?.let { wm?.removeView(it) }
        super.onDestroy()
    }
}
