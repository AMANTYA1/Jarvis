package com.jarvis.mine

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.app.SearchManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.PlaybackParams
import android.os.BatteryManager
import android.provider.AlarmClock
import android.view.KeyEvent
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import android.os.Build
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.ContactsContract
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class VoiceService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speaking = false
    private var commandMode = false
    private var running = false
    private var listening = false
    private var processing = false
    private var lastStart = 0L
    private var sessionUntil = 0L
    private var sessionMs = 30000L
    private val hist = ArrayList<Pair<String, String>>()
    private var orbBg: GradientDrawable? = null
    private val endWords = setOf("bas", "bas karo", "bas itna hi", "ruko", "bye", "ok bye", "thanks", "thank you",
        "ok thanks", "dhanyawad", "shukriya", "बस", "बस करो", "बस इतना ही", "रुको", "बाय", "थैंक्यू", "थैंक यू",
        "धन्यवाद", "शुक्रिया", "ठीक है बस")
    private val speakTimeout = Runnable { if (speaking) { speaking = false; listen() } }
    private var wm: WindowManager? = null
    private var orb: TextView? = null
    private val baseWake = listOf("jarvis", "jarvish", "jaarvis", "जार्विस", "जारविस", "जर्विस", "जारवीस", "जार्विश", "जरविस", "जारवि", "जार्वि")
    private var wake: List<String> = baseWake

    // Settings Dashboard se aane wali values
    private var natural = true
    private var voiceName = "Kore"
    private var rate = 1.0f
    private var pitch = 1.0f
    private var track: AudioTrack? = null
    private var speakGen = 0
    private var natBlockedUntil = 0L
    private var sosPending = 0L
    private val queue = ArrayList<String>()       // jo kaam abhi busy hone ki wajah se ruka hai
    private var currentTask = ""
    private val pcmCache = LinkedHashMap<String, ByteArray>()
    private var shakeOn = false
    private var shakeCount = 0
    private var shakeFirst = 0L
    private var shakeCool = 0L
    private val shakeL = object : SensorEventListener {
        override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        override fun onSensorChanged(e: SensorEvent) {
            val g = Math.sqrt((e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]).toDouble()) / 9.81
            val now = System.currentTimeMillis()
            if (g < 2.8 || now < shakeCool) return
            if (now - shakeFirst > 3000) { shakeFirst = now; shakeCount = 0 }
            if (now - shakeFirst >= 0) shakeCount++
            if (shakeCount >= 12) { shakeCount = 0; shakeCool = now + 30000L; h.post { shakeSos() } }
        }
    }

    private var chatMode = false
    private var chatPkg = ""
    private var chatBusy = false
    private var lastChatKey = ""
    private var lastSent = ""
    private var chatActive = 0L
    private var lastChatErr = 0L

    private val chatLoop = object : Runnable {
        override fun run() {
            if (!running || !chatMode) return
            if (System.currentTimeMillis() - chatActive > 20 * 60 * 1000L) {
                chatMode = false; updateOrb()
                announce("Chat me 20 minute se kuch nahi hua, main baat karna band kar raha hu")
                return
            }
            try { chatTick() } catch (e: Exception) { chatBusy = false }
            h.postDelayed(this, 1500)
        }
    }

    private fun chatTick() {
        if (chatBusy) return
        val a = JarvisAccess.inst ?: return
        if (a.foregroundPkg() != chatPkg) return
        val msgs = a.readChat() ?: return
        val last = msgs.last()
        // Apna hi bheja hua message (ya jo side galat padh li gayi) ho to jawab mat do -> apne se baat nahi hogi
        if (!last.incoming || last.text == lastSent || AutoReply.isMine(last.text)) return
        val k = msgs.count { it.incoming }.toString() + "|" + msgs.takeLast(3).joinToString("|") { it.text }
        if (k == lastChatKey) return
        lastChatKey = k
        chatBusy = true
        chatActive = System.currentTimeMillis()
        val apiKey = getSharedPreferences("j", MODE_PRIVATE).getString("key", "") ?: ""
        val convo = msgs.takeLast(12).joinToString("\n") { (if (it.incoming) "THEM: " else "OWNER: ") + it.text }
        Thread {
            val r = if (apiKey.isEmpty()) null else AutoReply.generateChat(apiKey, convo)
            h.post { chatReply(r) }
        }.start()
    }

    private fun chatReply(r: JSONObject?) {
        val reply = r?.optString("reply")?.trim() ?: ""
        if (r?.optBoolean("escalate") == true) announce("Chat me kuch zaroori pucha gaya, dekh lo")
        if (r == null) {
            // API fail: ek baar dobara koshish (agle tick par), aur batata hai
            h.postDelayed({ lastChatKey = "" }, 5000)
            chatBusy = false
            if (System.currentTimeMillis() - lastChatErr > 60000L) { lastChatErr = System.currentTimeMillis(); announce("Chat ka jawab nahi bana paaya, dobara koshish kar raha hu") }
            return
        }
        if (!chatMode || reply.isEmpty()) { chatBusy = false; return }
        if (!AutoReply.allowed("screen")) {
            chatBusy = false
            if (System.currentTimeMillis() - lastChatErr > 60000L) { lastChatErr = System.currentTimeMillis(); announce("Chat me reply ki limit lag gayi, thodi der baad chalega") }
            return
        }
        h.postDelayed({
            val a = JarvisAccess.inst
            if (chatMode && a != null && a.foregroundPkg() == chatPkg && a.typeReply(reply)) {
                lastSent = reply
                AutoReply.noteSent(reply)
                h.postDelayed({
                    a.clickSend()
                    AutoReply.addLog("Chat me reply diya: $reply")
                    chatActive = System.currentTimeMillis()
                    lastChatKey = ""      // agla message (same text ho tab bhi) naya maana jaye
                    chatBusy = false
                }, 800)
            } else chatBusy = false
        }, 1200L + (Math.random() * 1500).toLong())
    }

    private fun startChat(style: String): String {
        val a = JarvisAccess.inst ?: return "Pehle Accessibility ON karo"
        val pkg = a.foregroundPkg()
        if (pkg.isEmpty() || pkg == packageName) return "Pehle woh chat kholo jisme baat karni hai"
        if (style.isNotBlank()) AutoReply.style = style
        chatPkg = pkg; lastChatKey = ""; lastSent = ""; chatBusy = false
        chatActive = System.currentTimeMillis()
        chatMode = true
        h.removeCallbacks(chatLoop)
        h.postDelayed(chatLoop, 1500)
        updateOrb()
        return "Ji, ab main aapki taraf se baat karta hu. Rokna ho to bolo Jarvis bas karo"
    }

    // Active window kabhi kabhi turant nahi milti (keyboard/shade): thoda ruk kar 4 baar try
    private fun startChatAsync(style: String, tries: Int = 0) {
        val a = JarvisAccess.inst
        if (a == null) { processing = false; keepSession(); speak("Pehle Accessibility ON karo"); return }
        val pkg = a.foregroundPkg()
        val bad = pkg.isEmpty() || pkg == packageName || pkg == "com.android.systemui"
        if (bad && tries < 4) { h.postDelayed({ startChatAsync(style, tries + 1) }, 800); return }
        processing = false
        keepSession()
        speak(startChat(style))
    }

    private fun stopChat() {
        chatMode = false
        h.removeCallbacks(chatLoop)
        updateOrb()
    }

    private var vmNum = ""
    private var vmName = ""
    private var vmFile: File? = null

    companion object { var inst: VoiceService? = null }

    override fun onBind(i: Intent?): IBinder? = null

    // Auto-reply wagairah se aane wali suchna (zaroori ho to bolta hai, warna toast)
    fun announce(t: String, tries: Int = 0) {
        h.post {
            if (!speaking && !processing) speak(t)
            else if (tries < 8) h.postDelayed({ announce(t, tries + 1) }, 1500)
            else Toast.makeText(this, t, Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate() {
        super.onCreate()
        inst = this
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "jarvis").setContentTitle("Jarvis sun raha hai")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        tts = TextToSpeech(this) { s ->
            if (s == TextToSpeech.SUCCESS) {
                applyHindiVoice(); ttsReady = true
                tts?.setSpeechRate(rate); tts?.setPitch(pitch)
            }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) {
                if (id == "vm") { h.post { shareVoice() }; return }
                h.post { restoreLang(); speaking = false; if (inSession()) keepSession(); listen() }
            }
            @Deprecated("x") override fun onError(id: String?) {
                if (id == "vm") { h.post { processing = false; speak("Voice banane me dikkat aayi") }; return }
                h.post { restoreLang(); speaking = false; listen() }
            }
        })
        running = true
        val pf = getSharedPreferences("j", MODE_PRIVATE)
        loadSettings()
        NotifStore.load(pf)
        Cfg.autoLoad(pf)
        hist.addAll(Cfg.histLoad(pf))
        val bf = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(batRx, bf, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(batRx, bf)
        showOrb()
        if (pf.getBoolean("trade_on", false)) Trader.start(this)
        h.postDelayed({ listen() }, 800)
        h.postDelayed(watchdog, 3000)
    }

    private val watchdog = object : Runnable {
        override fun run() {
            if (!running) return
            if (listening && System.currentTimeMillis() - lastStart > 15000) { sr?.cancel(); listening = false }
            if (!listening && !speaking) listen()
            updateOrb()
            h.postDelayed(this, 3000)
        }
    }

    private fun showOrb() {
        if (!Settings.canDrawOverlays(this)) return
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val t = TextView(this)
        t.text = "J"
        t.gravity = Gravity.CENTER
        t.setTextColor(Color.WHITE)
        t.textSize = 11f
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(Color.parseColor("#CC00B8FF"))
        t.background = bg
        orbBg = bg
        t.setOnClickListener { if (Agent.busy) { Agent.stop = true } else { keepSession(); speak("Ji, boliye") } }
        val sz = (30 * resources.displayMetrics.density).toInt()
        val lp = WindowManager.LayoutParams(sz, sz, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.END
        lp.x = 20; lp.y = 300
        wm?.addView(t, lp)
        orb = t
    }

    private fun inSession() = System.currentTimeMillis() < sessionUntil

    private fun keepSession() { sessionUntil = System.currentTimeMillis() + sessionMs; updateOrb() }

    private fun endSession() { sessionUntil = 0L; updateOrb() }

    private fun updateOrb() {
        orbBg?.setColor(Color.parseColor(if (chatMode) "#CCFF9800" else if (inSession()) "#CC3DDC84" else "#CC00B8FF"))
    }

    // Emoji / markdown hata deta hai taaki awaaz natural lage
    private fun cleanForSpeech(t: String): String =
        t.replace(Regex("[\\p{So}\\u200d\\ufe0f]"), "").replace(Regex("[*_#`~]"), "").replace(Regex("\\s+"), " ").trim()

    private fun speak(text: String) {
        sr?.cancel()
        listening = false
        stopTrack()
        val clean = cleanForSpeech(text)
        if (clean.isBlank()) { speaking = false; h.postDelayed({ listen() }, 200); return }
        val gen = ++speakGen
        val key = apiKey()
        // Natural (Gemini) awaaz: key ho, translate wali alag bhasha na ho, aur haal me fail na hua ho
        if (natural && key.isNotEmpty() && !langRestore && clean.length <= 400 && System.currentTimeMillis() > natBlockedUntil) {
            speaking = true
            h.removeCallbacks(speakTimeout)
            h.postDelayed(speakTimeout, 25000L + clean.length * 100L)
            val v = voiceName
            val ck = "$v|$clean"
            val cached = synchronized(pcmCache) { pcmCache[ck] }
            if (cached != null) { playPcm(cached, gen); return }
            Thread {
                val pcm = Net.ttsGemini(key, clean, v)
                if (pcm != null && pcm.size >= 2000 && clean.length <= 60) synchronized(pcmCache) {
                    pcmCache[ck] = pcm
                    while (pcmCache.size > 20) pcmCache.remove(pcmCache.keys.first())
                }
                h.post {
                    if (gen != speakGen || !running) return@post
                    if (pcm == null || pcm.size < 2000) {
                        natBlockedUntil = System.currentTimeMillis() + 60000L   // 1 minute phone ki awaaz
                        phoneSpeak(clean)
                    } else playPcm(pcm, gen)
                }
            }.start()
            return
        }
        phoneSpeak(clean)
    }

    // Phone ki apni TTS awaaz (fallback)
    private fun phoneSpeak(text: String) {
        if (!ttsReady) { speaking = false; h.postDelayed({ listen() }, 200); return }
        speaking = true
        val r = tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u")
        if (r != TextToSpeech.SUCCESS) { speaking = false; h.postDelayed({ listen() }, 200); return }
        h.removeCallbacks(speakTimeout)
        h.postDelayed(speakTimeout, 4000L + text.length * 120L)
    }

    private fun stopTrack() {
        try { track?.stop() } catch (e: Exception) { }
        try { track?.release() } catch (e: Exception) { }
        track = null
    }

    private fun finishSpeak(gen: Int) {
        if (gen != speakGen) return
        stopTrack()
        h.removeCallbacks(speakTimeout)
        restoreLang(); speaking = false
        if (inSession()) keepSession()
        listen()
    }

    // Gemini ki awaaz (24kHz PCM) bajata hai, speed/pitch Settings se
    private fun playPcm(pcm: ByteArray, gen: Int) {
        try {
            val hz = 24000
            val minBuf = AudioTrack.getMinBufferSize(hz, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val t = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(hz).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(maxOf(pcm.size, minBuf))
                .setTransferMode(AudioTrack.MODE_STATIC).build()
            t.write(pcm, 0, pcm.size)
            val frames = pcm.size / 2
            try { t.playbackParams = PlaybackParams().setSpeed(rate).setPitch(pitch) } catch (e: Exception) { }
            t.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
                override fun onMarkerReached(a: AudioTrack?) { finishSpeak(gen) }
                override fun onPeriodicNotification(a: AudioTrack?) {}
            })
            t.setNotificationMarkerPosition((frames - 1).coerceAtLeast(1))
            track = t
            val ms = (frames * 1000L / hz / rate).toLong()
            h.removeCallbacks(speakTimeout)
            h.postDelayed(speakTimeout, ms + 3000L)
            t.play()
        } catch (e: Exception) {
            stopTrack()
            natBlockedUntil = System.currentTimeMillis() + 60000L
            speaking = false
            h.post { listen() }
        }
    }

    private fun applyHindiVoice() {
        try {
            tts?.language = Locale("hi", "IN")
            // Sabse achhi quality wali Hindi/Indian awaaz chunna
            val best = tts?.voices?.filter { it.locale.language == "hi" || it.locale.country == "IN" }
                ?.maxByOrNull { it.quality }
            if (best != null && best.locale.language == "hi") tts?.voice = best
        } catch (e: Exception) { }
    }

    // Settings Dashboard ne kuch badla: dobara padho
    fun reloadSettings() { h.post { loadSettings() } }

    private fun loadSettings() {
        val pf = getSharedPreferences("j", MODE_PRIVATE)
        Net.init(pf)
        loadWake(Cfg.wake(pf))
        sessionMs = Cfg.sessionSec(pf) * 1000L
        natural = Cfg.natural(pf)
        voiceName = Cfg.voice(pf)
        rate = Cfg.rate(pf).coerceIn(50, 200) / 100f
        pitch = Cfg.pitch(pf).coerceIn(50, 150) / 100f
        natBlockedUntil = 0L
        setShake(Cfg.shakeSos(pf))
        tts?.setSpeechRate(rate)
        tts?.setPitch(pitch)
    }

    private fun setShake(on: Boolean) {
        val sm = getSystemService(SENSOR_SERVICE) as SensorManager
        if (on && !shakeOn) {
            val a = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
            sm.registerListener(shakeL, a, SensorManager.SENSOR_DELAY_GAME)
            shakeOn = true
        } else if (!on && shakeOn) { sm.unregisterListener(shakeL); shakeOn = false }
    }

    // Phone zor se hilaya: SOS (poochh kar, ya seedha agar instant ON ho)
    private fun shakeSos() {
        val pf = getSharedPreferences("j", MODE_PRIVATE)
        val l = Cfg.sos(pf)
        if (l.isEmpty()) { speak("Shake SOS ke liye pehle SOS contact chuno"); return }
        keepSession()
        if (Cfg.sosInstant(pf)) bg { ex.sos(l) }
        else { sosPending = System.currentTimeMillis() + 20000L; speak("SOS bhejun? Haan bolo, ya nahi") }
    }

    // Settings me "Test awaaz" dabane par
    fun preview() { h.post { keepSession(); speak("Namaste, main Jarvis hu. Ye meri awaaz hai, aapko kaisi lagi?") } }

    private fun listen() {
        if (!running) return
        // Pehla kaam khatam, bol bhi chuka: ab queue ka agla kaam
        if (!processing && !speaking && queue.isNotEmpty()) {
            val n = queue.removeAt(0)
            keepSession()
            process(n)
            return
        }
        if (speaking || listening) return
        if (sr == null) {
            sr = SpeechRecognizer.createSpeechRecognizer(this)
            sr?.setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    listening = false
                    val l = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    handle(l ?: ArrayList())
                }
                override fun onError(e: Int) {
                    listening = false
                    h.postDelayed({ listen() }, if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 500L else 100L)
                }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        i.putExtra("android.speech.extra.SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS", 1200L)
        i.putExtra("android.speech.extra.SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS", 1000L)
        listening = true
        lastStart = System.currentTimeMillis()
        try { sr?.startListening(i) } catch (e: Exception) { listening = false }
    }

    private fun stripWake(t: String): String {
        val low = t.lowercase()
        for (w in wake) {
            val i = low.indexOf(w)
            if (i >= 0) return t.substring(i + w.length).trim()
        }
        return t.trim()
    }

    private fun hasWake(t: String): Boolean {
        val low = t.lowercase()
        return wake.any { low.contains(it) }
    }

    private fun handle(list: List<String>) {
        if (list.isEmpty()) { listen(); return }
        // Phone dhundhne wali awaaz baj rahi ho to sirf "Jarvis bas" par ruke
        if (ex.isRinging()) {
            val stop = list.any { hasWake(it) } || list.any { it.lowercase().trim(' ', '.', '!', '?', ',') in endWords }
            if (stop) { ex.stopRing(); keepSession(); speak("Theek hai, band kar diya") } else listen()
            return
        }
        // Trade signal ki confirmation (haan / nahi)
        val tpend = Trader.pending
        if (tpend != null) {
            Trader.pending = null
            if (System.currentTimeMillis() < Trader.pendingUntil) {
                val said = list.joinToString(" ").lowercase()
                val yes = Regex("\\b(haan|han|haa|yes|yeah|lagao|laga do|laga|kar do|ok)\\b|हाँ|हां|लगा").containsMatchIn(said)
                keepSession()
                speak(if (yes) Trader.accept(this, tpend) else "Theek hai, trade skip kar diya")
                return
            }
        }
        // SOS ki confirmation (haan / nahi)
        if (System.currentTimeMillis() < sosPending) {
            sosPending = 0L
            val said = list.joinToString(" ").lowercase()
            val yes = Regex("\\b(haan|han|haa|yes|yeah|bhej|bhejo|bhej do|kar do|ok)\\b|हाँ|हां|भेज").containsMatchIn(said)
            keepSession()
            if (yes) { val l = Cfg.sos(getSharedPreferences("j", MODE_PRIVATE)); bg { ex.sos(l) } }
            else speak("Theek hai, SOS cancel kar diya")
            return
        }
        // Session chalu hai: bina "Jarvis" bole seedha command lo
        if (inSession() || commandMode) {
            commandMode = false
            val raw = list[0]
            val cmd = if (hasWake(raw)) stripWake(raw) else raw.trim()
            if (cmd.isEmpty()) { keepSession(); speak("Ji, boliye"); return }
            val norm = cmd.lowercase().trim(' ', '.', '!', '?', ',')
            if (norm in endWords) {
                queue.clear()
                if (chatMode) { stopChat(); endSession(); speak("Theek hai, chat band kar di"); return }
                endSession(); speak("Theek hai, jab zarurat ho Jarvis bolna"); return
            }
            keepSession()
            process(cmd)
            return
        }
        for (t in list) {
            if (hasWake(t)) {
                val cmd = stripWake(t)
                keepSession()
                if (cmd.isEmpty()) speak("Ji, boliye") else process(cmd)
                return
            }
        }
        listen()
    }

    private fun process(cmd: String) {
        if (processing) {
            if (cmd.trim().length >= 3 && queue.size < 5) {
                queue.add(cmd)
                keepSession()
                val cur = currentTask.take(40)
                speak(if (cur.isBlank()) "Sir, abhi ek kaam chal raha hai, iske baad ye karta hu"
                      else "Sir, abhi aapne $cur ka kaam diya hai, iske baad ye karta hu")
            } else if (queue.size >= 5) speak("Sir, queue full hai, thoda ruk jaiye")
            return
        }
        currentTask = cmd
        processing = true
        val quick = local(cmd)
        if (quick != null) { h.post { act(quick) }; return }
        Thread {
            val res = ask(cmd)
            h.post { act(res) }
        }.start()
    }

    private fun ask(cmd: String): JSONObject {
        val key = getSharedPreferences("j", MODE_PRIVATE).getString("key", "") ?: ""
        if (key.isEmpty() && Net.groqKey.isEmpty()) return JSONObject().put("action", "none").put("say", "Pehle app me API key daalo")
        val now = SimpleDateFormat("yyyy-MM-dd HH:mm, EEEE", Locale.US).format(Date())
        val sys = "You are Jarvis, a warm, friendly Hinglish voice assistant on the user's Android phone. Now: $now (local time). " +
            "Reply ONLY with JSON: " +
            "{\"action\":\"<action>\",\"arg\":\"string\",\"to\":\"string\",\"text\":\"string\",\"say\":\"short Hinglish reply\"}. " +
            "Actions: open_app (arg=app name) | call (arg=contact name or number) | click (arg=visible text to tap) | back | home | " +
            "youtube (arg=song or video search query, it auto-plays) | " +
            "whatsapp (arg=contact name in ENGLISH/Roman letters as saved in phone, or a number; text=message to send) | " +
            "voice_msg (send a WhatsApp VOICE message in Jarvis's voice: arg=contact in Roman letters, text=what to say, written in Devanagari Hindi, English words may stay Roman) | " +
            "autochat (Jarvis chats on WhatsApp on the user's behalf and auto-replies to that person's incoming messages: arg=contact name in Roman letters, or \"all\" for everyone; text=optional tone like pyar se, funny, formal) | " +
            "autochat_off (stop all auto replies) | autochat_log (tell what auto replies were sent) | " +
            "chat_takeover (the user is ON a chat screen in any app such as WhatsApp or Instagram and says things like 'Jarvis baat karo tum' or 'mere side se reply karo': Jarvis reads the open chat and keeps replying there as the user until told to stop; text=optional tone) | " +
            "chat_stop (stop replying on the user's behalf in the open chat) | " +
            "media (arg=play|pause|next|prev for the playing music/video) | volume (arg=up|down|mute or a number 0-100) | " +
            "flash (arg=on|off torch) | alarm (arg=24h time HH:MM, text=label) | timer (arg=seconds as number) | " +
            "system (arg=recents|screenshot|lock|quick_settings|notifications_panel) | scroll (arg=up|down; also use down for next reel/short) | " +
            "type (arg=text to type in the focused text box) | battery | time | maps (arg=place to navigate to) | search (arg=google query) | " +
            "sms (send a normal SMS: arg=contact name or number, text=message) | read_sms (read latest SMS) | answer_call | reject_call | " +
            "calendar (add event or reminder: arg=start time as yyyy-MM-dd HH:mm in 24h, resolve words like kal, parso, shaam using Now; text=title) | read_calendar (today's events) | " +
            "briefing (morning briefing: time, battery, events, important notifications) | find_phone (ring loudly) | stop_ring | location (tell where the phone is) | " +
            "read_screen (read and summarize the current screen; text=optional specific question) | " +
            "app_msg (send a message in Instagram or Telegram: arg=instagram|telegram, to=contact name as shown in that app, text=message) | " +
            "like (like the current reel, short or video) | comment (post a comment on the current reel or short: text=comment) | " +
            "see (take a photo with the camera and describe it, for 'ye kya hai') | " +
            "translate (arg=target language code like en, hi, es, fr, ta; text=the translated sentence; if the user says isko or ise, translate your previous reply) | " +
            "notif_important (read only important notifications such as OTP, family, urgent) | notif_auto (arg=on|off, automatically announce important notifications) | vip_add (arg=name whose messages are important) | " +
            "toggle (arg=wifi|bluetooth|hotspot, taps the quick settings tile) | screen_time (arg=optional app name, today's app usage) | " +
            "note_add (text=note) | note_read | set_wake (arg=an extra wake word, or reset) | " +
            "remind (set a reminder: arg=time as yyyy-MM-dd HH:mm in 24h, resolve kal, parso, shaam, 5 baje using Now; text=what to remind) | reminders_read | " +
            "missed (what did I miss: missed calls, unread SMS, important notifications) | " +
            "remember (store a lasting fact the user tells you about themselves, like birthdays, family, likes, plans; text=short fact in Hinglish, written about the user) | memory_read (tell what you remember) | forget (arg=keyword of the fact to delete, or all) | " +
            "sos (the user is in danger or says bachao/emergency/SOS: alerts the saved emergency contacts) | " +
            "trade_on (start watching gold XAUUSD for SMC trade setups) | trade_off | trade_now (analyse gold now and tell the setup) | " +
            "notifications (read recent notifications) | none (just answer in say) | " +
            "ignore (background noise, TV or someone else talking, not addressed to you; say must be empty). " +
            "For whatsapp: if the user dictated the exact message send it as is with spelling fixed. If they gave no message, or asked for " +
            "something nice/sweet/pyara, YOU write a short (1-2 lines), warm, natural Hinglish message in Roman script as if the user is sending it, " +
            "matching the relationship (mummy, friend, bhai, etc.); a heart or smiley emoji is fine. Never write abusive, threatening or deceptive text. " +
            "NEVER send money, do UPI, banking or payment actions, and never tap pay buttons: use action none and politely say you do not do payments. " +
            "Never write abusive, threatening or deceptive SMS or messages. " +
            "When the user says yaad rakho / remember this or shares a lasting personal fact, use remember. " +
            "Keep say short and natural, in Hinglish, like a friendly assistant."
        val facts = Cfg.facts(getSharedPreferences("j", MODE_PRIVATE))
        val memText = if (facts.isEmpty()) "" else " Things you remember about the user (use naturally when relevant, never recite them unasked): " + facts.joinToString("; ") + "."
        if (Net.groqKey.isNotEmpty() && Net.groqOn) {
            try {
                val g = Net.groqChat(Net.groqKey, sys + memText, hist.takeLast(6), cmd, true)
                if (g.first < 400) {
                    var gout = g.second.trim()
                    if (gout.startsWith("[")) gout = JSONArray(gout).getJSONObject(0).toString()
                    val gr = JSONObject(gout)
                    hist.add(Pair("user", cmd))
                    hist.add(Pair("model", gout))
                    while (hist.size > 12) hist.removeAt(0)
                    Cfg.histSave(getSharedPreferences("j", MODE_PRIVATE), hist)
                    return gr
                }
            } catch (e: Exception) {
            }
        }
        val contents = JSONArray()
        for ((role, txt) in hist.takeLast(6)) {
            contents.put(JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", txt))))
        }
        contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", cmd))))
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys + memText))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        return try {
            val (code, txt, _) = Net.gemini(key, body.toString())
            if (code >= 400 || code == 0) {
                val er = JSONObject().put("action", "none").put("say", Net.errSay(code))
                if (code == 401 || code == 403 || code == 400) er.put("err", "HTTP $code: " + txt.take(250))
                return er
            }
            var out = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text").trim()
            if (out.startsWith("[")) out = JSONArray(out).getJSONObject(0).toString()
            val r = JSONObject(out)
            hist.add(Pair("user", cmd))
            hist.add(Pair("model", out))
            while (hist.size > 12) hist.removeAt(0)
            Cfg.histSave(getSharedPreferences("j", MODE_PRIVATE), hist)
            r
        } catch (e: Exception) {
            JSONObject().put("action", "none").put("say", "Net me dikkat hai").put("err", e.toString().take(250))
        }
    }

    private fun act(o: JSONObject) {
        processing = false
        if (o.has("err")) Toast.makeText(this, o.optString("err"), Toast.LENGTH_LONG).show()
        val a = o.optString("action"); val arg = o.optString("arg"); var say = o.optString("say")
        val text = o.optString("text")
        var silent = false
        when (a) {
            "ignore" -> { listen(); return }
            "open_app" -> if (!openApp(arg)) say = "$arg nahi mila"
            "call" -> if (!call(arg)) say = "$arg ka number nahi mila"
            "click" -> if (JarvisAccess.inst?.clickText(arg) != true) say = "Screen par $arg nahi dikha, ya Accessibility band hai"
            "back" -> JarvisAccess.inst?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            "home" -> JarvisAccess.inst?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            "youtube" -> {
                openYoutube(arg)
                processing = true
                h.postDelayed({ autoPlay(0) }, 3000)
                if (say.isBlank()) say = "Ji, $arg laga raha hu"
            }
            "whatsapp" -> {
                val r = whatsapp(arg, text)
                if (r == null) { silent = true } else { say = r }
            }
            "voice_msg" -> {
                val r = voiceMsg(arg, text)
                if (r == null) { silent = true } else { say = r }
            }
            "autochat" -> {
                val who = arg.trim()
                if (who.equals("all", true) || who.equals("sabko", true)) AutoReply.all = true
                else if (who.isNotEmpty()) AutoReply.chats.add(who.lowercase())
                if (text.isNotBlank()) AutoReply.style = text
                Cfg.autoSave(getSharedPreferences("j", MODE_PRIVATE))
                if (say.isBlank()) say = "Theek hai, $who se main baat karunga"
            }
            "autochat_off" -> {
                AutoReply.all = false; AutoReply.chats.clear()
                Cfg.autoSave(getSharedPreferences("j", MODE_PRIVATE))
                if (say.isBlank()) say = "Auto reply band kar diya"
            }
            "autochat_log" -> say = AutoReply.summary()
            "chat_takeover" -> { silent = true; processing = true; startChatAsync(text) }
            "chat_stop" -> { stopChat(); if (say.isBlank()) say = "Theek hai, ab main baat nahi karunga" }
            "media" -> mediaKey(arg)
            "volume" -> volume(arg)
            "flash" -> if (!flash(arg)) say = "Torch nahi chal paayi"
            "alarm" -> if (!setAlarm(arg, text)) say = "Alarm ka time samajh nahi aaya"
            "timer" -> if (!setTimer(arg)) say = "Timer ka time samajh nahi aaya"
            "system" -> if (!system(arg)) say = "Ye abhi nahi ho paaya, Accessibility check karo"
            "scroll" -> if (JarvisAccess.inst?.scroll(arg) != true) say = "Scroll nahi ho paaya, Accessibility check karo"
            "type" -> if (JarvisAccess.inst?.typeText(arg) != true) say = "Text box select nahi hai"
            "battery" -> say = battery()
            "time" -> say = "Abhi " + SimpleDateFormat("h:mm a, EEEE d MMMM", Locale("en", "IN")).format(Date()) + " ho rahe hain"
            "maps" -> navigate(arg)
            "search" -> startActivity(Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.google.com/search?q=" + Uri.encode(arg))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "notifications" -> say = NotifStore.summary()
            "sms" -> say = ex.sms(arg, text)
            "read_sms" -> say = ex.readSms()
            "answer_call" -> { say = ex.answerCall(); endSession(); silent = say == "Call utha liya" }
            "reject_call" -> { say = ex.rejectCall(); endSession() }
            "calendar" -> say = ex.addEvent(arg, text)
            "read_calendar" -> say = ex.todayEvents()
            "briefing" -> { silent = true; bg { ex.briefing() } }
            "find_phone" -> say = ex.findPhone()
            "stop_ring" -> { ex.stopRing(); say = "Theek hai" }
            "location" -> { silent = true; bg { ex.where() } }
            "read_screen" -> {
                val acc = JarvisAccess.inst
                val txt = acc?.screenText() ?: ""
                if (acc == null) say = "Pehle Accessibility ON karo"
                else if (txt.isBlank()) say = "Screen par padhne layak kuch nahi dikha"
                else { silent = true; val k = apiKey(); bg { ex.explainScreen(k, txt, text) } }
            }
            "see" -> { ex.see(); if (say.isBlank()) say = "Camera khol raha hu" }
            "like" -> if (JarvisAccess.inst?.like() != true) say = "Like nahi ho paaya, Accessibility check karo"
            "comment" -> {
                if (text.isBlank()) say = "Kya comment likhna hai?"
                else { silent = true; processing = true; ex.comment(text) { r -> processing = false; keepSession(); speak(r) } }
            }
            "app_msg" -> {
                silent = true; processing = true
                ex.appMsg(arg, o.optString("to"), text) { r -> processing = false; keepSession(); speak(r) }
            }
            "toggle" -> { silent = true; processing = true; ex.toggle(arg) { r -> processing = false; keepSession(); speak(r) } }
            "screen_time" -> say = ex.screenTime(arg)
            "note_add" -> say = ex.noteAdd(text.ifBlank { arg })
            "trade_on" -> { Trader.setOn(this, true); say = "Trading mode ON. Gold par SMC setup dekhta rahunga, setup banne par bataunga" }
            "trade_off" -> { Trader.setOn(this, false); say = "Trading mode band kar diya" }
            "trade_now" -> { silent = true; bg { Trader.now(this) } }
            "note_read" -> say = ex.noteRead()
            "translate" -> { silent = true; speakLang(arg, text.ifBlank { say }) }
            "notif_important" -> say = NotifStore.important()
            "notif_auto" -> {
                val on = arg.lowercase() == "on"
                NotifStore.setAuto(getSharedPreferences("j", MODE_PRIVATE), on)
                if (say.isBlank()) say = if (on) "Ab sirf zaroori notification bataunga" else "Notification bolna band kar diya"
            }
            "vip_add" -> {
                NotifStore.addVip(getSharedPreferences("j", MODE_PRIVATE), arg)
                if (say.isBlank()) say = "$arg ko zaroori list me daal diya"
            }
            "remember" -> {
                val f = text.ifBlank { arg }
                if (f.isBlank()) say = "Kya yaad rakhna hai?"
                else { Cfg.factAdd(getSharedPreferences("j", MODE_PRIVATE), f); if (say.isBlank()) say = "Theek hai, yaad rakh liya" }
            }
            "memory_read" -> {
                val l = Cfg.facts(getSharedPreferences("j", MODE_PRIVATE))
                say = if (l.isEmpty()) "Abhi mujhe kuch yaad nahi hai" else "Mujhe ye yaad hai. " + l.takeLast(6).joinToString(". ")
            }
            "forget" -> {
                val n = Cfg.factForget(getSharedPreferences("j", MODE_PRIVATE), arg)
                say = if (n == 0) "Aisa kuch yaad nahi tha" else "Theek hai, bhool gaya"
            }
            "remind" -> say = ex.remind(arg, text)
            "reminders_read" -> say = ex.remindersRead()
            "missed" -> { silent = true; bg { ex.missed() } }
            "sos" -> {
                val pf = getSharedPreferences("j", MODE_PRIVATE)
                val l = Cfg.sos(pf)
                if (l.isEmpty()) say = "Koi SOS contact chuna nahi hai. App ki settings me SOS contacts chuno"
                else if (Cfg.sosInstant(pf)) { silent = true; bg { ex.sos(l) } }
                else { sosPending = System.currentTimeMillis() + 20000L; say = "SOS bhejun? Haan bolo, ya nahi" }
            }
            "set_wake" -> {
                val w = if (arg.equals("reset", true)) "" else arg.trim()
                getSharedPreferences("j", MODE_PRIVATE).edit().putString("wake", w).apply()
                loadWake(w)
                if (say.isBlank()) say = if (w.isEmpty()) "Wake word wapas sirf Jarvis kar diya" else "Ab $w bolkar bhi bula sakte ho"
            }
        }
        keepSession()
        if (!silent) speak(if (say.isBlank()) "Ho gaya" else say)
    }

    // ================= naye features ke helpers =================
    private val ex by lazy { Extras(this) }
    private var callRinging = 0L
    private var langRestore = false
    private var lowWarned = false

    private val batRx = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, i: Intent?) {
            if (i == null) return
            val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            if (lvl < 0 || sc <= 0) return
            val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            val pct = lvl * 100 / sc
            if (pct <= 20 && !charging) {
                if (!lowWarned) { lowWarned = true; announce("Battery sirf $pct percent reh gayi hai, charger laga lo") }
            } else if (pct > 25 || charging) lowWarned = false
        }
    }

    private fun apiKey(): String = getSharedPreferences("j", MODE_PRIVATE).getString("key", "") ?: ""

    private fun loadWake(custom: String) {
        wake = if (custom.isBlank()) baseWake else listOf(custom.lowercase().trim()) + baseWake
    }

    private fun restoreLang() {
        if (langRestore) { applyHindiVoice(); langRestore = false }
    }

    private fun speakLang(code: String, t: String) {
        val r = tts?.setLanguage(Locale.forLanguageTag(code.trim().ifEmpty { "en" }))
        Toast.makeText(this, t, Toast.LENGTH_LONG).show()
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.language = Locale("hi", "IN")
            speak("Is bhasha ki awaaz is phone me nahi hai, screen par likh diya")
        } else {
            langRestore = true
            speak(t)
        }
    }

    fun incomingCall(name: String) {
        h.post {
            callRinging = System.currentTimeMillis() + 40000L
            keepSession()
            speak(if (name.isEmpty()) "Koi call aa raha hai. Uthau ya kaat du?" else "$name ka call aa raha hai. Uthau ya kaat du?")
        }
    }

    // Background me kaam karke result bolta hai
    private fun bg(work: () -> String) {
        processing = true
        Thread {
            val r = try { work() } catch (e: Exception) { "Ye nahi ho paaya" }
            h.post { processing = false; keepSession(); speak(r) }
        }.start()
    }

    private fun anyOf(s: String, vararg k: String): Boolean = k.any { s.contains(it) }

    // Chhote kaam bina API ke, turant (API limit bachti hai)
    private fun local(cmd: String): JSONObject? {
        val s = cmd.lowercase().trim(' ', '.', '!', '?', ',')
        if (s.split(" ").size > 7) return null
        fun r(a: String, arg: String = "") = JSONObject().put("action", a).put("arg", arg).put("say", "")
        if (System.currentTimeMillis() < callRinging) {
            if (anyOf(s, "kaat", "cut", "reject", "nahi", "band", "काट", "मत")) { callRinging = 0L; return r("reject_call") }
            if (anyOf(s, "utha", "uthao", "attend", "pick", "haan", "receive", "उठा", "हां", "हाँ") || s == "han" || s == "ha") {
                callRinging = 0L; return r("answer_call")
            }
        }
        // "baat karo" jaise commands API ke bina seedha pakde jaate hain (taaki hamesha chalein)
        val tk = s.split(" ").size <= 5 && !anyOf(s, " se ", "से") &&
            anyOf(s, "baat karo", "baat kar lo", "बात करो", "बात कर लो", "tum baat", "chat sambhal", "चैट संभाल", "reply karo", "reply kar do", "रिप्लाई करो")
        if (tk || anyOf(s, "mere side se", "meri taraf se", "मेरी तरफ से", "मेरे साइड से")) return r("chat_takeover")
        if (chatMode && anyOf(s, "chat band", "baat mat karo", "chat stop", "reply mat", "चैट बंद")) return r("chat_stop")
        return when {
            anyOf(s, "trading on", "trade on", "trading chalu", "trading shuru", "ट्रेडिंग ऑन", "ट्रेडिंग चालू") -> r("trade_on")
            anyOf(s, "trading off", "trade off", "trading band", "ट्रेडिंग ऑफ", "ट्रेडिंग बंद") -> r("trade_off")
            anyOf(s, "gold kaisa", "gold signal", "gold ka signal", "gold setup", "gold analysis", "trade setup", "सोना सिग्नल") -> r("trade_now")
            (Regex("\\bsos\\b").containsMatchIn(s) || anyOf(s, "bachao", "emergency", "बचाओ", "एसओएस", "इमरजेंसी")) -> r("sos")
            anyOf(s, "kya yaad hai", "tumhe kya yaad", "tujhe kya yaad", "क्या याद है") -> r("memory_read")
            anyOf(s, "kya miss hua", "miss kya hua", "missed call", "मिस्ड कॉल", "kya miss") -> r("missed")
            anyOf(s, "mere reminder", "reminders sunao", "reminder sunao", "रिमाइंडर सुना") -> r("reminders_read")
            anyOf(s, "battery", "बैटरी") && !anyOf(s, "saver", " on", " off", "band") -> r("battery")
            anyOf(s, "kitne baje", "time kya", "samay kya", "what time", "कितने बजे", "टाइम क्या") -> r("time")
            anyOf(s, "torch", "flashlight", "टॉर्च", "फ्लैश") ->
                r("flash", if (anyOf(s, "off", "band", "बंद", "bujha", "बुझा")) "off" else "on")
            anyOf(s, "volume", "वॉल्यूम") -> {
                val n = s.filter { it.isDigit() }
                when {
                    n.isNotEmpty() -> r("volume", n)
                    anyOf(s, "mute", "band", "बंद") -> r("volume", "mute")
                    anyOf(s, "badha", "zyada", "increase", "बढ़ा", "तेज") || s.endsWith(" up") -> r("volume", "up")
                    anyOf(s, "kam", "ghata", "decrease", "कम", "घटा") || s.endsWith(" down") -> r("volume", "down")
                    else -> null
                }
            }
            s in setOf("back", "wapas jao", "peeche jao", "back jao", "पीछे जाओ", "वापस जाओ") -> r("back")
            s in setOf("home", "home jao", "होम जाओ", "ghar jao") -> r("home")
            anyOf(s, "agla reel", "next reel", "next short", "agli reel", "agla short", "अगला रील", "अगली रील") -> r("scroll", "down")
            anyOf(s, "pichla reel", "previous reel", "pichli reel", "पिछला रील") -> r("scroll", "up")
            anyOf(s, "like kar", "लाइक कर") && s.split(" ").size <= 4 -> r("like")
            anyOf(s, "good morning", "suprabhat", "सुप्रभात", "गुड मॉर्निंग", "briefing", "ब्रीफिंग") -> r("briefing")
            anyOf(s, "phone kahan", "phone kidhar", "फोन कहां", "फोन कहाँ") -> r("find_phone")
            anyOf(s, "main kahan hu", "main kahan hoon", "meri location", "mai kahan") -> r("location")
            anyOf(s, "mere notes", "notes sunao", "note sunao", "नोट्स सुना") -> r("note_read")
            anyOf(s, "screen time", "स्क्रीन टाइम") -> r("screen_time")
            anyOf(s, "ye kya hai", "yeh kya hai", "yah kya hai", "ये क्या है") -> r("see")
            anyOf(s, "sms padh", "एसएमएस पढ़") -> r("read_sms")
            anyOf(s, "zaroori notification", "important notification", "otp padh", "ओटीपी पढ़") -> r("notif_important")
            anyOf(s, "screen par kya", "screen pe kya", "स्क्रीन पर क्या") -> r("read_screen")
            else -> null
        }
    }

    private fun openYoutube(q: String) {
        val uri = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))
        val i = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(Intent(i).setPackage("com.google.android.youtube")) }
        catch (e: Exception) { startActivity(i) }
    }

    // YouTube khulne ke baad pehla video khud tap karta hai (retry ke saath)
    private fun autoPlay(tries: Int) {
        if (!running) return
        val a = JarvisAccess.inst
        if (a == null) {
            processing = false
            Toast.makeText(this, "Accessibility ON karo, tabhi gana khud chalega", Toast.LENGTH_LONG).show()
            return
        }
        if (a.playFirstVideo()) { processing = false; return }
        if (tries >= 8) { a.tapFirstResultFallback(); processing = false; return }
        h.postDelayed({ autoPlay(tries + 1) }, 1000)
    }

    private fun findNumber(arg: String): String {
        var num = arg.filter { it.isDigit() || it == '+' }
        if (num.length >= 5) return num
        num = ""
        val P = ContactsContract.CommonDataKinds.Phone.NUMBER
        val names = listOf(arg.trim()) + arg.trim().split(" ").filter { it.length > 2 }
        for (n in names) {
            contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(P),
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", arrayOf("%$n%"), null)?.use {
                if (it.moveToFirst()) num = it.getString(0)
            }
            if (num.isNotEmpty()) break
        }
        return num
    }

    // return null => result baad me khud bolega; warna turant bolne wala text
    private fun whatsapp(name: String, msg: String): String? {
        if (msg.isBlank()) return "Kya message bhejna hai?"
        val num = waNumber(name)
        if (num.isEmpty()) return "$name ka number nahi mila"
        val uri = Uri.parse("https://wa.me/$num?text=" + Uri.encode(msg))
        var ok = false
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                ok = true; break
            } catch (e: Exception) { }
        }
        if (!ok) return "WhatsApp nahi mila"
        processing = true
        h.postDelayed({ sendWa(name, 0, "$name ko message bhej diya") }, 2500)
        return null
    }

    private fun waNumber(name: String): String {
        var num = findNumber(name).filter { it.isDigit() }
        if (num.length == 11 && num.startsWith("0")) num = num.substring(1)
        if (num.length == 10) num = "91$num"
        return num
    }

    // Jarvis ki awaaz me voice file banata hai, phir WhatsApp me bhejta hai
    private fun voiceMsg(name: String, msg: String): String? {
        if (msg.isBlank()) return "Voice me kya bolna hai?"
        val num = waNumber(name)
        if (num.isEmpty()) return "$name ka number nahi mila"
        if (!ttsReady) return "Awaaz abhi ready nahi hai"
        val dir = File(cacheDir, "voice")
        dir.mkdirs()
        val f = File(dir, "jarvis_voice.wav")
        vmNum = num; vmName = name; vmFile = f
        processing = true
        sr?.cancel(); listening = false
        val r = tts?.synthesizeToFile(msg, Bundle(), f, "vm")
        if (r != TextToSpeech.SUCCESS) { processing = false; return "Voice banane me dikkat aayi" }
        return null
    }

    private fun shareVoice() {
        val f = vmFile
        if (f == null || !f.exists()) { processing = false; speak("Voice file nahi bani"); return }
        val uri = FileProvider.getUriForFile(this, "$packageName.fp", f)
        var ok = false
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            try {
                grantUriPermission(pkg, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                val i = Intent(Intent.ACTION_SEND).setType("audio/*")
                    .putExtra(Intent.EXTRA_STREAM, uri)
                    .putExtra("jid", "$vmNum@s.whatsapp.net")
                    .setPackage(pkg)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(i)
                ok = true; break
            } catch (e: Exception) { }
        }
        if (!ok) { processing = false; speak("WhatsApp nahi mila"); return }
        h.postDelayed({ sendWa(vmName, 0, "$vmName ko voice message bhej diya") }, 3000)
    }

    private fun mediaKey(arg: String) {
        val code = when (arg.lowercase()) {
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "prev", "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        val am = getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun volume(arg: String) {
        val am = getSystemService(AudioManager::class.java)
        val st = AudioManager.STREAM_MUSIC
        val n = arg.filter { it.isDigit() }.toIntOrNull()
        when {
            n != null -> am.setStreamVolume(st, am.getStreamMaxVolume(st) * n.coerceIn(0, 100) / 100, AudioManager.FLAG_SHOW_UI)
            arg.lowercase() == "up" -> am.adjustStreamVolume(st, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            arg.lowercase() == "down" -> am.adjustStreamVolume(st, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            arg.lowercase() == "mute" -> am.setStreamVolume(st, 0, AudioManager.FLAG_SHOW_UI)
        }
    }

    private fun flash(arg: String): Boolean {
        return try {
            val cm = getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return false
            cm.setTorchMode(id, arg.lowercase() == "on")
            true
        } catch (e: Exception) { false }
    }

    private fun setAlarm(arg: String, label: String): Boolean {
        val p = arg.split(":")
        val hh = p.getOrNull(0)?.trim()?.toIntOrNull() ?: return false
        val mm = p.getOrNull(1)?.trim()?.toIntOrNull() ?: 0
        return try {
            startActivity(Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, hh).putExtra(AlarmClock.EXTRA_MINUTES, mm)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label.ifBlank { "Jarvis alarm" })
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        } catch (e: Exception) { false }
    }

    private fun setTimer(arg: String): Boolean {
        val sec = arg.filter { it.isDigit() }.toIntOrNull() ?: return false
        return try {
            startActivity(Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, sec)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        } catch (e: Exception) { false }
    }

    private fun system(arg: String): Boolean {
        val a = JarvisAccess.inst ?: return false
        return when (arg.lowercase()) {
            "recents" -> a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
            "quick_settings" -> a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
            "notifications_panel" -> a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            "screenshot" -> Build.VERSION.SDK_INT >= 28 && a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
            "lock" -> Build.VERSION.SDK_INT >= 28 && a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
            else -> false
        }
    }

    private fun battery(): String {
        val bm = getSystemService(BatteryManager::class.java)
        return "Battery " + bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) + " percent hai"
    }

    private fun navigate(place: String) {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(place)))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(Intent(i).setPackage("com.google.android.apps.maps")) }
        catch (e: Exception) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(place)))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun sendWa(name: String, tries: Int, okMsg: String) {
        if (!running) return
        val a = JarvisAccess.inst
        if (a == null) {
            processing = false
            speak("Accessibility ON karo, tabhi main send daba paunga")
            return
        }
        if (a.clickSend()) {
            processing = false
            speak(okMsg)
            return
        }
        if (tries >= 8) {
            processing = false
            speak("Send button nahi mila, message ready hai, ek baar khud daba do")
            return
        }
        h.postDelayed({ sendWa(name, tries + 1, okMsg) }, 1000)
    }

    private fun openApp(name: String): Boolean {
        val pm = packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val m = list.firstOrNull { it.loadLabel(pm).toString().contains(name, true) } ?: return false
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(m.activityInfo.packageName, m.activityInfo.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        return true
    }

    private fun call(arg: String): Boolean {
        val num = findNumber(arg)
        if (num.isEmpty()) return false
        startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }

    override fun onDestroy() {
        inst = null
        running = false
        Trader.running = false
        try { unregisterReceiver(batRx) } catch (e: Exception) { }
        ex.stopRing()
        h.removeCallbacksAndMessages(null)
        sr?.destroy()
        stopTrack()
        setShake(false)
        tts?.shutdown()
        orb?.let { wm?.removeView(it) }
        super.onDestroy()
    }
}
