package com.jarvis.mine

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.ContactsContract
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class VoiceService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speaking = false
    private var commandMode = false
    private var running = false
    private var wm: WindowManager? = null
    private var orb: TextView? = null
    private val wake = listOf("jarvis", "जार्विस", "जारविस", "जर्विस", "जारवीस")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "jarvis").setContentTitle("Jarvis sun raha hai")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        tts = TextToSpeech(this) { s ->
            if (s == TextToSpeech.SUCCESS) { tts?.language = Locale("hi", "IN"); ttsReady = true }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { h.post { speaking = false; listen() } }
            @Deprecated("x") override fun onError(id: String?) { h.post { speaking = false; listen() } }
        })
        running = true
        showOrb()
        h.postDelayed({ listen() }, 800)
    }

    private fun showOrb() {
        if (!Settings.canDrawOverlays(this)) return
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val t = TextView(this)
        t.text = "J"
        t.gravity = Gravity.CENTER
        t.setTextColor(Color.WHITE)
        t.textSize = 20f
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(Color.parseColor("#CC00B8FF"))
        t.background = bg
        t.setOnClickListener { commandMode = true; speak("Ji, boliye") }
        val lp = WindowManager.LayoutParams(140, 140, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.END
        lp.x = 20; lp.y = 300
        wm?.addView(t, lp)
        orb = t
    }

    private fun speak(text: String) {
        sr?.cancel()
        if (!ttsReady || text.isBlank()) { speaking = false; h.postDelayed({ listen() }, 300); return }
        speaking = true
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    private fun listen() {
        if (!running || speaking) return
        if (sr == null) {
            sr = SpeechRecognizer.createSpeechRecognizer(this)
            sr?.setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                    handle(t)
                }
                override fun onError(e: Int) { h.postDelayed({ listen() }, 700) }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        sr?.startListening(i)
    }

    private fun handle(t: String) {
        if (commandMode) { commandMode = false; process(t); return }
        val low = t.lowercase()
        var cut = -1; var len = 0
        for (w in wake) { val i = low.indexOf(w); if (i >= 0) { cut = i; len = w.length; break } }
        if (cut < 0) { listen(); return }
        val cmd = t.substring(cut + len).trim()
        if (cmd.isEmpty()) { commandMode = true; speak("Ji, boliye") } else process(cmd)
    }

    private fun process(cmd: String) {
        Thread {
            val res = ask(cmd)
            h.post { act(res) }
        }.start()
    }

    private fun ask(cmd: String): JSONObject {
        val key = getSharedPreferences("j", MODE_PRIVATE).getString("key", "") ?: ""
        if (key.isEmpty()) return JSONObject().put("action", "none").put("say", "Pehle app me API key daalo")
        val sys = "You are Jarvis, a Hinglish voice assistant on an Android phone. Reply ONLY with JSON: " +
            "{\"action\":\"open_app|call|click|back|home|youtube|notifications|none\",\"arg\":\"string\",\"say\":\"short Hinglish reply\"}. " +
            "open_app: arg=app name. call: arg=contact name or phone number. click: arg=visible text on screen to tap. " +
            "youtube: arg=search query. notifications: read recent notifications. none: just answer in say."
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", cmd)))))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        return try {
            val c = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$key")
                .openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 15000; c.readTimeout = 30000
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val txt = (if (c.responseCode < 400) c.inputStream else c.errorStream).bufferedReader().readText()
            val out = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            JSONObject(out)
        } catch (e: Exception) {
            JSONObject().put("action", "none").put("say", "Net ya API key me dikkat hai")
        }
    }

    private fun act(o: JSONObject) {
        val a = o.optString("action"); val arg = o.optString("arg"); var say = o.optString("say")
        when (a) {
            "open_app" -> if (!openApp(arg)) say = "$arg nahi mila"
            "call" -> if (!call(arg)) say = "$arg ka number nahi mila"
            "click" -> if (JarvisAccess.inst?.clickText(arg) != true) say = "Screen par $arg nahi dikha, ya Accessibility band hai"
            "back" -> JarvisAccess.inst?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            "home" -> JarvisAccess.inst?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            "youtube" -> startActivity(Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(arg))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "notifications" -> say = NotifStore.summary()
        }
        speak(if (say.isBlank()) "Ho gaya" else say)
    }

    private fun openApp(name: String): Boolean {
        val pm = packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val m = list.firstOrNull { it.loadLabel(pm).toString().contains(name, true) } ?: return false
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(m.activityInfo.packageName, m.activityInfo.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        return true
    }

    private fun call(arg: String): Boolean {
        var num = arg.filter { it.isDigit() || it == '+' }
        if (num.length < 5) {
            num = ""
            val P = ContactsContract.CommonDataKinds.Phone.NUMBER
            contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(P),
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", arrayOf("%$arg%"), null)?.use {
                if (it.moveToFirst()) num = it.getString(0)
            }
        }
        if (num.isEmpty()) return false
        startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }

    override fun onDestroy() {
        running = false
        sr?.destroy()
        tts?.shutdown()
        orb?.let { wm?.removeView(it) }
        super.onDestroy()
    }
}
