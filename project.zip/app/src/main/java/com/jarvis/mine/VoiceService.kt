package com.jarvis.mine

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.ContactsContract
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class VoiceService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speaking = false
    private var commandMode = false
    private var running = false
    private var listening = false
    private var processing = false
    private var lastStart = 0L
    private var wm: WindowManager? = null
    private var orb: TextView? = null
    private val wake = listOf("jarvis", "jarvish", "jaarvis", "जार्विस", "जारविस", "जर्विस", "जारवीस", "जार्विश", "जरविस", "जारवि", "जार्वि")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "jarvis").setContentTitle("Jarvis sun raha hai")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        tts = TextToSpeech(this) { s ->
            if (s == TextToSpeech.SUCCESS) { tts?.language = Locale("hi", "IN"); ttsReady = true }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { h.post { speaking = false; listen() } }
            @Deprecated("x") override fun onError(id: String?) { h.post { speaking = false; listen() } }
        })
        running = true
        showOrb()
        h.postDelayed({ listen() }, 800)
        h.postDelayed(watchdog, 3000)
    }

    private val watchdog = object : Runnable {
        override fun run() {
            if (!running) return
            if (listening && System.currentTimeMillis() - lastStart > 15000) { sr?.cancel(); listening = false }
            if (!listening && !speaking && !processing) listen()
            h.postDelayed(this, 3000)
        }
    }

    private fun showOrb() {
        if (!Settings.canDrawOverlays(this)) return
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val t = TextView(this)
        t.text = "J"
        t.gravity = Gravity.CENTER
        t.setTextColor(Color.WHITE)
        t.textSize = 20f
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(Color.parseColor("#CC00B8FF"))
        t.background = bg
        t.setOnClickListener { commandMode = true; speak("Ji, boliye") }
        val lp = WindowManager.LayoutParams(140, 140, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.END
        lp.x = 20; lp.y = 300
        wm?.addView(t, lp)
        orb = t
    }

    private fun speak(text: String) {
        sr?.cancel()
        listening = false
        if (!ttsReady || text.isBlank()) { speaking = false; h.postDelayed({ listen() }, 200); return }
        speaking = true
        val r = tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u")
        if (r != TextToSpeech.SUCCESS) { speaking = false; h.postDelayed({ listen() }, 200); return }
        h.postDelayed({ if (speaking) { speaking = false; listen() } }, 4000L + text.length * 120L)
    }

    private fun listen() {
        if (!running || speaking || processing || listening) return
        if (sr == null) {
            sr = SpeechRecognizer.createSpeechRecognizer(this)
            sr?.setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    listening = false
                    val l = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    handle(l ?: ArrayList())
                }
                override fun onError(e: Int) {
                    listening = false
                    h.postDelayed({ listen() }, if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 500L else 100L)
                }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        i.putExtra("android.speech.extra.SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS", 1200L)
        i.putExtra("android.speech.extra.SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS", 1000L)
        listening = true
        lastStart = System.currentTimeMillis()
        try { sr?.startListening(i) } catch (e: Exception) { listening = false }
    }

    private fun handle(list: List<String>) {
        if (list.isEmpty()) { listen(); return }
        if (commandMode) { commandMode = false; process(list[0]); return }
        for (t in list) {
            val low = t.lowercase()
            for (w in wake) {
                val i = low.indexOf(w)
                if (i >= 0) {
                    val cmd = t.substring(i + w.length).trim()
                    if (cmd.isEmpty()) { commandMode = true; speak("Ji, boliye") } else process(cmd)
                    return
                }
            }
        }
        listen()
    }

    private fun process(cmd: String) {
        processing = true
        Thread {
            val res = ask(cmd)
            h.post { act(res) }
        }.start()
    }

    private fun ask(cmd: String): JSONObject {
        val key = getSharedPreferences("j", MODE_PRIVATE).getString("key", "") ?: ""
        if (key.isEmpty()) return JSONObject().put("action", "none").put("say", "Pehle app me API key daalo")
        val sys = "You are Jarvis, a Hinglish voice assistant on an Android phone. Reply ONLY with JSON: " +
            "{\"action\":\"open_app|call|click|back|home|youtube|notifications|none\",\"arg\":\"string\",\"say\":\"short Hinglish reply\"}. " +
            "open_app: arg=app name. call: arg=contact name or phone number. click: arg=visible text on screen to tap. " +
            "youtube: arg=search query. notifications: read recent notifications. none: just answer in say."
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", cmd)))))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        return try {
            val (code, txt) = Net.post("https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent", key, body.toString())
            if (code >= 400) {
                return JSONObject().put("action", "none").put("say", "API key me dikkat hai")
                    .put("err", "HTTP $code: " + txt.take(250))
            }
            val out = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            JSONObject(out)
        } catch (e: Exception) {
            JSONObject().put("action", "none").put("say", "Net me dikkat hai").put("err", e.toString().take(250))
        }
    }

    private fun act(o: JSONObject) {
        processing = false
        if (o.has("err")) Toast.makeText(this, o.optString("err"), Toast.LENGTH_LONG).show()
        val a = o.optString("action"); val arg = o.optString("arg"); var say = o.optString("say")
        when (a) {
            "open_app" -> if (!openApp(arg)) say = "$arg nahi mila"
            "call" -> if (!call(arg)) say = "$arg ka number nahi mila"
            "click" -> if (JarvisAccess.inst?.clickText(arg) != true) say = "Screen par $arg nahi dikha, ya Accessibility band hai"
            "back" -> JarvisAccess.inst?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            "home" -> JarvisAccess.inst?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            "youtube" -> startActivity(Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(arg))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "notifications" -> say = NotifStore.summary()
        }
        speak(if (say.isBlank()) "Ho gaya" else say)
    }

    private fun openApp(name: String): Boolean {
        val pm = packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val m = list.firstOrNull { it.loadLabel(pm).toString().contains(name, true) } ?: return false
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(m.activityInfo.packageName, m.activityInfo.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        return true
    }

    private fun call(arg: String): Boolean {
        var num = arg.filter { it.isDigit() || it == '+' }
        if (num.length < 5) {
            num = ""
            val P = ContactsContract.CommonDataKinds.Phone.NUMBER
            contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(P),
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", arrayOf("%$arg%"), null)?.use {
                if (it.moveToFirst()) num = it.getString(0)
            }
        }
        if (num.isEmpty()) return false
        startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }

    override fun onDestroy() {
        running = false
        h.removeCallbacksAndMessages(null)
        sr?.destroy()
        tts?.shutdown()
        orb?.let { wm?.removeView(it) }
        super.onDestroy()
    }
}
