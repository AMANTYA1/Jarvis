package com.jarvis.mine

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

object NotifStore {
    val items = ArrayList<String>()
    fun summary(): String =
        if (items.isEmpty()) "Koi naya notification nahi hai" else items.takeLast(5).joinToString(". ")
}

class NotifListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val e = sbn.notification.extras
        val title = e.getCharSequence("android.title")?.toString() ?: return
        val text = e.getCharSequence("android.text")?.toString() ?: ""
        NotifStore.items.add("$title: $text")
        if (NotifStore.items.size > 20) NotifStore.items.removeAt(0)
    }
}
