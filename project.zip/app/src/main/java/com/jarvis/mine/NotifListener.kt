package com.jarvis.mine

import android.app.Notification
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject
import kotlin.random.Random

object NotifStore {
    val items = ArrayList<String>()
    fun summary(): String =
        if (items.isEmpty()) "Koi naya notification nahi hai" else items.takeLast(5).joinToString(". ")
}

// WhatsApp par owner ki taraf se auto-reply ka dimaag
object AutoReply {
    val chats = LinkedHashSet<String>()
    @Volatile var all = false
    @Volatile var style = "natural, friendly"
    val log = ArrayList<String>()
    private val hist = HashMap<String, ArrayList<Pair<String, String>>>()
    private val sent = HashMap<String, ArrayList<Long>>()
    private val seen = LinkedHashSet<String>()

    fun enabledFor(title: String): Boolean {
        if (all) return true
        val t = title.lowercase()
        return chats.any { t.contains(it) || it.contains(t) }
    }

    @Synchronized fun firstTime(k: String): Boolean {
        if (!seen.add(k)) return false
        if (seen.size > 50) seen.remove(seen.first())
        return true
    }

    // loop/spam se bachne ke liye: ek chat me 4 sec gap, ghante me max 20 reply
    @Synchronized fun allowed(title: String): Boolean {
        val now = System.currentTimeMillis()
        val l = sent.getOrPut(title) { ArrayList() }
        l.removeAll { now - it > 3600000L }
        if (l.size >= 20) return false
        if (l.isNotEmpty() && now - l.last() < 4000) return false
        l.add(now)
        return true
    }

    @Synchronized fun addLog(s: String) { log.add(s); while (log.size > 20) log.removeAt(0) }

    fun summary(): String =
        if (log.isEmpty()) "Abhi tak koi auto reply nahi gaya" else log.takeLast(3).joinToString(". ")

    // Khuli chat ke poore transcript se owner ka agla reply banata hai
    fun generateChat(key: String, convo: String): JSONObject? {
        val sys = "You are chatting in a phone messaging app on behalf of the phone's owner. " +
            "Below is the visible conversation: THEM is the other person, OWNER is what the owner already sent. " +
            "Write the owner's next reply to THEM's latest message(s): short (1-2 lines), natural Hinglish in Roman script " +
            "(or the language THEM uses), tone: $style, mirror their mood. " +
            "Stay honest: if they sincerely ask whether they are talking to a bot or AI, say that Jarvis, the owner's assistant, is replying. " +
            "Never agree to money transfers, meetings or plans, and never share OTPs, passwords, addresses or other private info; " +
            "in such cases set escalate=true and reply that the owner will get back to them soon. " +
            "If the last line is not clearly a message from THEM that needs an answer, or the talk has naturally ended, set reply to an empty string. " +
            "Reply ONLY JSON: {\"reply\":\"...\",\"escalate\":false}"
        val contents = JSONArray().put(JSONObject().put("role", "user")
            .put("parts", JSONArray().put(JSONObject().put("text", convo))))
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        return try {
            val (code, txt, _) = Net.gemini(key, body.toString())
            if (code >= 400) return null
            var out = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text").trim()
            if (out.startsWith("[")) out = JSONArray(out).getJSONObject(0).toString()
            JSONObject(out)
        } catch (e: Exception) { null }
    }

    fun generate(key: String, title: String, text: String): JSONObject? {
        val sys = "You are replying on WhatsApp on behalf of the phone's owner to \"$title\". " +
            "Write exactly what the owner would send: short (1-2 lines), natural Hinglish in Roman script, tone: $style, " +
            "mirror the other person's language and mood. " +
            "Stay honest: if they sincerely ask whether they are talking to a bot or AI, say that Jarvis, the owner's assistant, is replying. " +
            "Never agree to money transfers, meetings or plans, and never share OTPs, passwords, addresses or other private info; " +
            "in such cases set escalate=true and reply that the owner will get back to them soon. " +
            "If the message is only a voice note, photo or sticker you cannot see, ask them to type it. " +
            "If no reply is needed (a plain ok or thumbs-up that ends the talk), set reply to an empty string. " +
            "Reply ONLY JSON: {\"reply\":\"...\",\"escalate\":false}"
        val contents = JSONArray()
        val h = synchronized(this) { ArrayList(hist.getOrPut(title) { ArrayList() }.takeLast(8)) }
        for ((role, t) in h) {
            contents.put(JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", t))))
        }
        contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text))))
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        return try {
            val (code, txt, _) = Net.gemini(key, body.toString())
            if (code >= 400) return null
            var out = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text").trim()
            if (out.startsWith("[")) out = JSONArray(out).getJSONObject(0).toString()
            val r = JSONObject(out)
            synchronized(this) {
                val l = hist.getOrPut(title) { ArrayList() }
                l.add(Pair("user", text))
                l.add(Pair("model", r.optString("reply")))
                while (l.size > 16) l.removeAt(0)
            }
            r
        } catch (e: Exception) { null }
    }
}

class NotifListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val e = sbn.notification.extras
        val title = e.getCharSequence("android.title")?.toString() ?: return
        val text = e.getCharSequence("android.text")?.toString() ?: ""
        NotifStore.items.add("$title: $text")
        if (NotifStore.items.size > 20) NotifStore.items.removeAt(0)
        if (sbn.packageName == "com.whatsapp" || sbn.packageName == "com.whatsapp.w4b") {
            try { maybeAutoReply(sbn) } catch (x: Exception) { }
        }
    }

    private fun maybeAutoReply(sbn: StatusBarNotification) {
        if (!AutoReply.all && AutoReply.chats.isEmpty()) return
        val n = sbn.notification
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        val e = n.extras
        if (e.getBoolean("android.isGroupConversation", false)) return
        if (e.getCharSequence("android.conversationTitle") != null) return
        val title = e.getCharSequence("android.title")?.toString() ?: return
        val text = e.getCharSequence("android.text")?.toString() ?: return
        if (title.equals("WhatsApp", true)) return
        if (Regex("\\d+ (new )?messages?.*", RegexOption.IGNORE_CASE).matches(text)) return
        if (!AutoReply.enabledFor(title)) return
        val act = n.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true } ?: return
        if (!AutoReply.firstTime("${sbn.key}|${sbn.postTime}|$text")) return
        val key = getSharedPreferences("j", MODE_PRIVATE).getString("key", "") ?: ""
        if (key.isEmpty()) return
        Thread {
            val r = AutoReply.generate(key, title, text) ?: return@Thread
            val reply = r.optString("reply").trim()
            if (r.optBoolean("escalate")) VoiceService.inst?.announce("$title ne pucha: $text")
            if (reply.isEmpty() || !AutoReply.allowed(title)) return@Thread
            try { Thread.sleep(3000L + Random.nextInt(3000)) } catch (x: Exception) { }
            val ri = act.remoteInputs
            val b = Bundle()
            b.putCharSequence(ri[0].resultKey, reply)
            val i = Intent()
            android.app.RemoteInput.addResultsToIntent(ri, i, b)
            try {
                act.actionIntent.send(this, 0, i)
                AutoReply.addLog("$title ko reply diya: $reply")
            } catch (x: Exception) { }
        }.start()
    }
}
