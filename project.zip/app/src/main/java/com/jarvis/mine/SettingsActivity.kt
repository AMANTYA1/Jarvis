package com.jarvis.mine

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.ContactsContract
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Premium Settings Dashboard
class SettingsActivity : Activity() {
    private val BG1 = Color.parseColor("#060A16")
    private val BG2 = Color.parseColor("#0E1530")
    private val CARD = Color.parseColor("#131B36")
    private val SEL = Color.parseColor("#1A2C4D")
    private val LINE = Color.parseColor("#26325A")
    private val CYAN = Color.parseColor("#00E5FF")
    private val BLUE = Color.parseColor("#3D7BFF")
    private val SOFT = Color.parseColor("#A9B4D0")
    private val GRAY = Color.parseColor("#7C87A6")
    private val RED = Color.parseColor("#FF5C7A")
    private val GREEN = Color.parseColor("#3DDC97")
    private lateinit var p: SharedPreferences
    private lateinit var root: LinearLayout
    private lateinit var sosBox: LinearLayout
    private lateinit var remBox: LinearLayout
    private lateinit var factBox: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
    private fun applyNow() { VoiceService.inst?.reloadSettings() }

    private fun shape(fill: Int, stroke: Int, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.setStroke(dp(1), stroke)
        g.cornerRadius = dp(r).toFloat()
        return g
    }

    private fun grad(a: Int, b: Int, r: Int): GradientDrawable {
        val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(a, b))
        g.cornerRadius = dp(r).toFloat()
        return g
    }

    private fun lp(top: Int = 0, w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(w, h)
        l.topMargin = dp(top)
        return l
    }

    private fun text(parent: LinearLayout, t: String, size: Float, color: Int, bold: Boolean = false, top: Int = 0): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = size
        tv.setTextColor(color)
        if (bold) tv.typeface = Typeface.DEFAULT_BOLD
        parent.addView(tv, lp(top))
        return tv
    }

    // Section card: icon + title + subtitle
    private fun section(icon: String, name: String, sub: String): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(18), dp(16), dp(18), dp(18))
        c.background = shape(CARD, LINE, 22)
        c.elevation = dp(4).toFloat()
        root.addView(c, lp(16))
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val ic = TextView(this)
        ic.text = icon
        ic.textSize = 20f
        ic.gravity = Gravity.CENTER
        ic.background = grad(Color.parseColor("#1C3A6B"), Color.parseColor("#143055"), 14)
        head.addView(ic, LinearLayout.LayoutParams(dp(44), dp(44)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(12), 0, 0, 0)
        text(col, name, 17f, Color.WHITE, true)
        text(col, sub, 12f, GRAY)
        head.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        c.addView(head)
        return c
    }

    private fun primary(parent: LinearLayout, t: String, click: () -> Unit) {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setTextColor(Color.parseColor("#04101F"))
        b.typeface = Typeface.DEFAULT_BOLD
        b.background = grad(CYAN, BLUE, 14)
        b.stateListAnimator = null
        b.setOnClickListener { click() }
        parent.addView(b, lp(12, ViewGroup.LayoutParams.MATCH_PARENT, dp(50)))
    }

    private fun ghost(parent: LinearLayout, t: String, color: Int = SOFT, click: () -> Unit) {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setTextColor(color)
        b.background = shape(Color.TRANSPARENT, color, 14)
        b.stateListAnimator = null
        b.setOnClickListener { click() }
        parent.addView(b, lp(10, ViewGroup.LayoutParams.MATCH_PARENT, dp(46)))
    }

    private fun switch(parent: LinearLayout, t: String, on: Boolean, change: (Boolean) -> Unit) {
        val sw = Switch(this)
        sw.text = t
        sw.setTextColor(Color.WHITE)
        sw.isChecked = on
        sw.thumbTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(CYAN, SOFT))
        sw.trackTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(Color.parseColor("#55007E8A"), Color.parseColor("#33FFFFFF")))
        sw.setOnCheckedChangeListener { _, v -> change(v) }
        parent.addView(sw, lp(12))
    }

    // Tile-style chuninda list (radio ki jagah)
    private fun choice(parent: LinearLayout, items: List<Pair<String, String>>, current: String, pick: (String) -> Unit) {
        val views = ArrayList<TextView>()
        var cur = current
        fun paint() {
            for ((i, v) in views.withIndex()) {
                val sel = items[i].first == cur
                v.background = shape(if (sel) SEL else BG2, if (sel) CYAN else LINE, 12)
                v.setTextColor(if (sel) Color.WHITE else SOFT)
                v.text = (if (sel) "✓   " else "") + items[i].second
            }
        }
        for ((i, item) in items.withIndex()) {
            val tv = TextView(this)
            tv.textSize = 14f
            tv.setPadding(dp(14), dp(12), dp(14), dp(12))
            tv.setOnClickListener { cur = item.first; paint(); pick(cur) }
            views.add(tv)
            parent.addView(tv, lp(if (i == 0) 12 else 8))
        }
        paint()
    }

    private fun slider(parent: LinearLayout, name: String, min: Int, max: Int, cur: Int, fmt: (Int) -> String, save: (Int) -> Unit) {
        val tv = text(parent, name + "  ·  " + fmt(cur), 13f, SOFT, false, 14)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = cur.coerceIn(min, max) - min
        sb.progressTintList = ColorStateList.valueOf(CYAN)
        sb.thumbTintList = ColorStateList.valueOf(CYAN)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { tv.text = name + "  ·  " + fmt(v + min) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { save(sb.progress + min); applyNow() }
        })
        parent.addView(sb, lp(2))
    }

    private fun stat(parent: LinearLayout, k: String, v: String) {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER
        c.setPadding(dp(6), dp(12), dp(6), dp(12))
        c.background = shape(CARD, LINE, 16)
        text(c, v, 15f, CYAN, true).gravity = Gravity.CENTER
        text(c, k, 11f, GRAY, false, 2).gravity = Gravity.CENTER
        val l = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        l.marginEnd = dp(8)
        parent.addView(c, l)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG1
        window.navigationBarColor = BG1
        p = getSharedPreferences("j", MODE_PRIVATE)

        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(18), dp(40), dp(18), dp(40))

        text(root, "JARVIS", 12f, CYAN, true).letterSpacing = 0.4f
        text(root, "Control Center", 30f, Color.WHITE, true, 2)
        text(root, "Apne assistant ko apne hisaab se set karo. Badlav turant lagu hote hain.", 13f, GRAY, false, 4)

        val stats = LinearLayout(this)
        stats.orientation = LinearLayout.HORIZONTAL
        val mdl = Cfg.MODELS.firstOrNull { it.first == Cfg.model(p) }?.first ?: "auto"
        stat(stats, "AI model", if (mdl == "auto") "Auto" else mdl.removePrefix("gemini-").removeSuffix("-latest").take(10))
        stat(stats, "Awaaz", if (Cfg.natural(p)) Cfg.voice(p) else "Phone")
        stat(stats, "SOS", Cfg.sos(p).size.toString())
        root.addView(stats, lp(18))

        // ---------- AI model ----------
        val mc = section("🧠", "AI Model", "Jarvis kis Gemini model se soche")
        choice(mc, Cfg.MODELS, Cfg.model(p)) { v -> p.edit().putString("model", v).apply(); Net.preferred = v; applyNow() }

        // ---------- Wake word ----------
        val wc = section("🎙", "Wake Word", "\"Jarvis\" hamesha chalega, apna extra bhi daalo")
        val et = EditText(this)
        et.hint = "jaise: hey buddy"
        et.setHintTextColor(GRAY)
        et.setTextColor(Color.WHITE)
        et.setSingleLine()
        et.setText(Cfg.wake(p))
        et.setPadding(dp(14), dp(12), dp(14), dp(12))
        et.background = shape(BG2, LINE, 12)
        wc.addView(et, lp(14))
        primary(wc, "Wake word save karo") {
            val w = et.text.toString().trim().lowercase()
            if (w.isNotEmpty() && w.length < 3) toast("Kam se kam 3 akshar chahiye")
            else { p.edit().putString("wake", w).apply(); applyNow(); toast(if (w.isEmpty()) "Sirf Jarvis chalega" else "Ab \"$w\" bhi chalega") }
        }
        ghost(wc, "Reset (sirf Jarvis)") { et.setText(""); p.edit().putString("wake", "").apply(); applyNow(); toast("Reset ho gaya") }
        text(wc, "Bulane ke baad kitni der sunta rahe", 13f, SOFT, false, 16)
        choice(wc, listOf("15" to "15 second", "30" to "30 second", "60" to "1 minute", "120" to "2 minute"), Cfg.sessionSec(p).toString()) { v ->
            p.edit().putInt("session_sec", v.toInt()).apply(); applyNow()
        }

        // ---------- Voice ----------
        val vc = section("🔊", "Awaaz", "Natural voice, speed aur pitch")
        switch(vc, "Natural awaaz (Gemini)", Cfg.natural(p)) { v -> p.edit().putBoolean("natural", v).apply(); applyNow() }
        text(vc, "Insaan jaisi awaaz, internet chahiye. Fail ho to phone ki awaaz chalti hai.", 12f, GRAY, false, 2)
        choice(vc, Cfg.VOICES, Cfg.voice(p)) { v -> p.edit().putString("voice", v).apply(); applyNow() }
        slider(vc, "Speed", 50, 200, Cfg.rate(p), { v -> "%.2fx".format(v / 100f) }) { v -> p.edit().putInt("rate", v).apply() }
        slider(vc, "Pitch", 50, 150, Cfg.pitch(p), { v -> "%.2fx".format(v / 100f) }) { v -> p.edit().putInt("pitch", v).apply() }
        primary(vc, "▶  Test awaaz") {
            val s = VoiceService.inst
            if (s == null) toast("Pehle main screen se START JARVIS dabao") else { applyNow(); s.preview() }
        }

        // ---------- Speed ----------
        val fc = section("⚡", "Speed", "Jawab jaldi aane ke liye")
        switch(fc, "Tez mode (kam sochna, jaldi jawab)", Cfg.fast(p)) { v -> p.edit().putBoolean("fast", v).apply(); Net.init(p) }
        text(fc, "Extra API keys daalo (ek line me ek, max 4). Ek key ki limit lage to turant dusri chalti hai, aur dheema hone par dono parallel try hoti hain.", 12f, GRAY, false, 2)
        val ek = EditText(this)
        ek.hint = "AIza...\nAIza..."
        ek.setHintTextColor(GRAY)
        ek.setTextColor(Color.WHITE)
        ek.textSize = 13f
        ek.minLines = 3
        ek.gravity = Gravity.TOP
        ek.setText(p.getString("keys_extra", ""))
        ek.setPadding(dp(14), dp(12), dp(14), dp(12))
        ek.background = shape(BG2, LINE, 12)
        fc.addView(ek, lp(12))
        primary(fc, "Keys save karo") {
            p.edit().putString("keys_extra", ek.text.toString().trim()).apply()
            Net.init(p)
            toast(Cfg.extraKeys(p).size.toString() + " extra key save hui")
        }
        text(fc, "Dimaag #2: Groq (bahut tez). Free key console.groq.com se milti hai. Pehle Groq jawab deta hai, na chale to Gemini keys.", 12f, GRAY, false, 2)
        switch(fc, "Groq pehle use karo (tez)", Cfg.groqOn(p)) { v -> p.edit().putBoolean("groq_on", v).apply(); Net.init(p) }
        val gk = EditText(this)
        gk.hint = "gsk_..."
        gk.setHintTextColor(GRAY)
        gk.setTextColor(Color.WHITE)
        gk.textSize = 13f
        gk.setSingleLine()
        gk.setText(p.getString("groq", ""))
        gk.setPadding(dp(14), dp(12), dp(14), dp(12))
        gk.background = shape(BG2, LINE, 12)
        fc.addView(gk, lp(12))
        primary(fc, "Groq key save + test") {
            val gkey = gk.text.toString().trim()
            p.edit().putString("groq", gkey).apply()
            Net.init(p)
            if (gkey.isEmpty()) {
                toast("Groq key hata di")
            } else {
                toast("Groq test ho raha hai...")
                Thread {
                    val g = try {
                        Net.groqChat(gkey, "Reply with JSON only.", emptyList(), "{\"ok\":true}", true, 15)
                    } catch (e: Exception) {
                        Triple(0, e.javaClass.simpleName, "")
                    }
                    runOnUiThread {
                        toast(if (g.first < 400) "Groq chal raha hai (" + g.third + ")" else "Groq error " + g.first + ": " + g.second.take(80))
                    }
                }.start()
            }
        }

        // ---------- Memory ----------
        val yc = section("💭", "Yaaddasht", "Bolo: \"Jarvis yaad rakho, mummy ka birthday 12 March\"")
        factBox = LinearLayout(this)
        factBox.orientation = LinearLayout.VERTICAL
        yc.addView(factBox, lp(8))
        ghost(yc, "Sab bhool jao", RED) { Cfg.factForget(p, "all"); renderFacts() }
        renderFacts()

        // ---------- Reminders ----------
        val rc = section("⏰", "Reminders", "Bolo: \"Jarvis kal 5 baje dawai yaad dilana\"")
        remBox = LinearLayout(this)
        remBox.orientation = LinearLayout.VERTICAL
        rc.addView(remBox, lp(8))
        renderRems()

        // ---------- SOS ----------
        val sc = section("🚨", "SOS", "Emergency me location ke saath alert")
        text(sc, "Max 5 contacts. \"Jarvis SOS\" / \"bachao\" bolne ya phone zor se hilane par SMS jayega aur pehle contact ko call lagega.", 12f, GRAY, false, 10)
        sosBox = LinearLayout(this)
        sosBox.orientation = LinearLayout.VERTICAL
        sc.addView(sosBox, lp(6))
        primary(sc, "+  Contact chuno") { pickContact() }
        switch(sc, "Phone hilane par SOS (shake)", Cfg.shakeSos(p)) { v -> p.edit().putBoolean("shake_sos", v).apply(); applyNow() }
        switch(sc, "Bina poochhe seedha bhejo", Cfg.sosInstant(p)) { v -> p.edit().putBoolean("sos_instant", v).apply() }
        text(sc, "Bina poochhe OFF ho to Jarvis pehle poochhta hai \"SOS bhejun?\" taaki galti se na chale.", 12f, GRAY, false, 2)
        ghost(sc, "SOS abhi bhejo", RED) { confirmSos() }
        renderSos()

        val sv = ScrollView(this)
        sv.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(BG1, BG2))
        sv.isFillViewport = true
        sv.addView(root)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        if (::remBox.isInitialized) renderRems()
        if (::factBox.isInitialized) renderFacts()
    }

    private fun renderRems() {
        remBox.removeAllViews()
        val now = System.currentTimeMillis()
        val l = Cfg.rems(p).filter { it.at > now }
        if (l.isEmpty()) { text(remBox, "Abhi koi reminder nahi hai", 13f, GRAY, false, 4); return }
        val f = SimpleDateFormat("d MMM, h:mm a", Locale("en", "IN"))
        for (r in l) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(14), dp(10), dp(8), dp(10))
            row.background = shape(BG2, LINE, 12)
            val tv = TextView(this)
            tv.text = r.text + "\n" + f.format(Date(r.at))
            tv.setTextColor(Color.WHITE)
            tv.textSize = 14f
            row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val x = TextView(this)
            x.text = "✕"
            x.textSize = 18f
            x.setTextColor(RED)
            x.setPadding(dp(14), dp(6), dp(14), dp(6))
            x.setOnClickListener { ReminderReceiver.cancel(this, r.id, r.text); Cfg.remRemove(p, r.id); renderRems() }
            row.addView(x)
            remBox.addView(row, lp(8))
        }
    }

    private fun renderFacts() {
        factBox.removeAllViews()
        val l = Cfg.facts(p)
        if (l.isEmpty()) { text(factBox, "Abhi kuch yaad nahi hai", 13f, GRAY, false, 4); return }
        for ((i, f) in l.withIndex()) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(14), dp(10), dp(8), dp(10))
            row.background = shape(BG2, LINE, 12)
            val tv = TextView(this)
            tv.text = f
            tv.setTextColor(Color.WHITE)
            tv.textSize = 14f
            row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val x = TextView(this)
            x.text = "✕"
            x.textSize = 18f
            x.setTextColor(RED)
            x.setPadding(dp(14), dp(6), dp(14), dp(6))
            x.setOnClickListener { Cfg.factRemove(p, i); renderFacts() }
            row.addView(x)
            factBox.addView(row, lp(8))
        }
    }

    private fun renderSos() {
        sosBox.removeAllViews()
        val l = Cfg.sos(p)
        if (l.isEmpty()) text(sosBox, "Abhi koi contact nahi chuna", 13f, GRAY, false, 4)
        for ((i, c) in l.withIndex()) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(14), dp(10), dp(8), dp(10))
            row.background = shape(BG2, LINE, 12)
            val tv = TextView(this)
            tv.text = "${i + 1}.  ${c.name}\n${c.number}"
            tv.setTextColor(Color.WHITE)
            tv.textSize = 14f
            row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val x = TextView(this)
            x.text = "✕"
            x.textSize = 18f
            x.setTextColor(RED)
            x.setPadding(dp(14), dp(6), dp(14), dp(6))
            x.setOnClickListener { Cfg.sosRemove(p, i); renderSos() }
            row.addView(x)
            sosBox.addView(row, lp(8))
        }
    }

    private fun pickContact() {
        if (Cfg.sos(p).size >= 5) { toast("Max 5 contacts"); return }
        try {
            startActivityForResult(Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI), 7)
        } catch (e: Exception) { toast("Contacts app nahi khul paaya") }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 7 || res != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            contentResolver.query(uri, arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER), null, null, null)?.use {
                if (it.moveToFirst()) {
                    Cfg.sosAdd(p, it.getString(0) ?: "", it.getString(1) ?: "")
                    renderSos()
                }
            }
        } catch (e: Exception) { toast("Contact padh nahi paaya") }
    }

    private fun confirmSos() {
        val l = Cfg.sos(p)
        if (l.isEmpty()) { toast("Pehle SOS contact chuno"); return }
        AlertDialog.Builder(this)
            .setTitle("SOS bhejun?")
            .setMessage("Chune hue ${l.size} contact(s) ko asli SMS jayega aur ${l[0].name} ko call lagega.")
            .setPositiveButton("Haan, bhejo") { _, _ ->
                Thread {
                    val r = Extras(applicationContext).sos(l)
                    runOnUiThread { toast(r) }
                }.start()
            }
            .setNegativeButton("Nahi", null)
            .show()
    }
}
