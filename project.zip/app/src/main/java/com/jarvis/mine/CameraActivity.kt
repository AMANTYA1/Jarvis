package com.jarvis.mine

import android.app.Activity
import android.content.ClipData
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File

// "Ye kya hai" ke liye: camera kholkar photo leta hai aur Gemini se poochta hai
class CameraActivity : Activity() {
    private var file: File? = null
    private val h = Handler(Looper.getMainLooper())
    private var shot = false
    private var tries = 0

    private val tick = object : Runnable {
        override fun run() {
            if (isFinishing || tries++ > 14) return
            val a = JarvisAccess.inst
            if (a != null) {
                if (!shot) { if (a.clickShutter()) shot = true } else a.clickConfirm()
            }
            h.postDelayed(this, 1300)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val dir = File(cacheDir, "photo")
        dir.mkdirs()
        val f = File(dir, "see.jpg")
        if (f.exists()) f.delete()
        file = f
        val uri = FileProvider.getUriForFile(this, "$packageName.fp", f)
        val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, uri)
            .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        i.clipData = ClipData.newRawUri("", uri)
        try {
            startActivityForResult(i, 7)
            h.postDelayed(tick, 2500)
        } catch (e: Exception) {
            VoiceService.inst?.announce("Camera nahi khul paaya")
            finish()
        }
    }

    @Deprecated("x")
    override fun onActivityResult(req: Int, res: Int, d: Intent?) {
        super.onActivityResult(req, res, d)
        val f = file
        if (res != RESULT_OK || f == null || !f.exists() || f.length() == 0L) {
            VoiceService.inst?.announce("Photo nahi li gayi")
            finish()
            return
        }
        val key = getSharedPreferences("j", MODE_PRIVATE).getString("key", "") ?: ""
        Thread { VoiceService.inst?.announce(Net.describe(f, key)) }.start()
        finish()
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
