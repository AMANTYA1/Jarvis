package com.jarvis.mine

import android.graphics.BitmapFactory
import android.util.Base64
import okhttp3.Dns
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.Inet4Address
import java.net.InetAddress
import java.util.concurrent.TimeUnit

object Net {
    val client: OkHttpClient = OkHttpClient.Builder()
        .dns(object : Dns {
            override fun lookup(hostname: String): List<InetAddress> =
                Dns.SYSTEM.lookup(hostname).sortedBy { it !is Inet4Address }
        })
        .protocols(listOf(Protocol.HTTP_1_1))
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .callTimeout(30, TimeUnit.SECONDS)
        .build()

    private val models = listOf("gemini-flash-lite-latest", "gemini-flash-latest", "gemini-2.5-flash-lite", "gemini-2.5-flash")
    var goodModel: String? = null
    // Settings Dashboard me chuna hua model ("auto" = apne aap)
    @Volatile var preferred: String = "auto"
    // Natural awaaz ke liye Gemini TTS model
    var ttsModel = "gemini-2.5-flash-preview-tts"

    fun post(url: String, key: String, body: String, sec: Long = 15): Pair<Int, String> {
        val c = client.newBuilder().callTimeout(sec, TimeUnit.SECONDS).readTimeout(sec, TimeUnit.SECONDS).build()
        val req = Request.Builder().url(url).header("X-goog-api-key", key)
            .post(body.toRequestBody("application/json".toMediaType())).build()
        c.newCall(req).execute().use { return Pair(it.code, it.body?.string() ?: "") }
    }

    private fun retryable(c: Int) = c == 0 || c == 429 || c == 500 || c == 502 || c == 503 || c == 504

    // Extra API keys (Settings me), tez mode (thinking band)
    @Volatile var extraKeys: List<String> = emptyList()
    @Volatile var fast: Boolean = true
    private val thinkRejected: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet()

    fun init(p: android.content.SharedPreferences) {
        preferred = Cfg.model(p)
        extraKeys = Cfg.extraKeys(p)
        fast = Cfg.fast(p)
    }

    private fun withFast(body: String, m: String): String {
        if (!fast || !m.contains("flash") || m in thinkRejected) return body
        return try {
            val o = JSONObject(body)
            val g = o.optJSONObject("generationConfig") ?: JSONObject()
            g.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
            o.put("generationConfig", g)
            o.toString()
        } catch (e: Exception) { body }
    }

    private class Att(val model: String, val key: String)

    private fun one(a: Att, body: String, sec: Long): Triple<Int, String, String> {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/${a.model}:generateContent"
        var r = post(url, a.key, withFast(body, a.model), sec)
        // Model "thinking" setting nahi maanta to bina uske dobara
        if (r.first == 400 && r.second.contains("think", true) && a.model !in thinkRejected) {
            thinkRejected.add(a.model)
            r = post(url, a.key, body, sec)
        }
        return Triple(r.first, r.second, a.model)
    }

    // Tez: pehli request 2.5 second me na aaye to dusra model/key saath me bhej deta hai, jo pehle aaye wahi lete hain.
    // Limit (429) / busy (503) par bina ruke agla key/model.
    fun gemini(key: String, body: String, sec: Long = 15): Triple<Int, String, String> {
        val keys = (listOf(key) + extraKeys).filter { it.isNotBlank() }.distinct()
        if (keys.isEmpty()) return Triple(401, "no key", "")
        val order = (listOfNotNull(preferred.takeIf { it != "auto" && it.isNotBlank() }, goodModel) + models).distinct()
        val atts = ArrayList<Att>()
        for ((i, m) in order.withIndex()) atts.add(Att(m, keys[i % keys.size]))
        for ((i, m) in order.take(2).withIndex()) atts.add(Att(m, keys[(i + 1) % keys.size]))
        val deadline = System.currentTimeMillis() + 40000L
        var last = Triple(0, "no response", "")
        val pool = java.util.concurrent.Executors.newCachedThreadPool()
        val q = java.util.concurrent.LinkedBlockingQueue<Triple<Int, String, String>>()
        var launched = 0
        var finished = 0
        fun launch() {
            val a = atts[launched++]
            pool.execute { q.put(try { one(a, body, sec) } catch (e: Exception) { Triple(0, e.javaClass.simpleName, a.model) }) }
        }
        try {
            launch()
            while (finished < launched || launched < atts.size) {
                if (System.currentTimeMillis() > deadline) break
                val r = q.poll(if (launched < atts.size) 2500L else 8000L, TimeUnit.MILLISECONDS)
                if (r == null) { if (launched < atts.size) launch(); continue }
                finished++
                last = r
                if (r.first < 400) { goodModel = r.third; return r }
                val keyBad = r.first == 401 || r.first == 403 || (r.first == 400 && r.second.contains("API key"))
                if (keyBad && keys.size == 1) return r
                if (launched < atts.size) launch()
            }
        } finally { pool.shutdown() }
        return last
    }

    // Gemini se natural awaaz. Return: 24kHz 16-bit mono PCM bytes, fail par null (tab phone ki awaaz use hoti hai)
    fun ttsGemini(key: String, text: String, voice: String): ByteArray? {
        val prompt = "Say in a warm, natural, friendly conversational tone, like a real person talking to a friend: $text"
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig",
                    JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
        return try {
            val (code, txt) = post("https://generativelanguage.googleapis.com/v1beta/models/$ttsModel:generateContent", key, body.toString(), 20)
            if (code >= 400) return null
            val part = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
            val inl = part.optJSONObject("inlineData") ?: part.optJSONObject("inline_data") ?: return null
            Base64.decode(inl.getString("data"), Base64.DEFAULT)
        } catch (e: Exception) { null }
    }

    // Error code ko bolne layak Hinglish me badalta hai
    fun errSay(code: Int): String = when {
        code == 401 || code == 403 -> "API key me dikkat hai, app me check karo"
        code == 400 -> "Request me dikkat aayi, dobara bolo"
        code == 429 -> "Abhi API ki limit lag gayi hai, thodi der baad bolo"
        code == 0 -> "Net ya server se jawab nahi aaya, thodi der baad bolo"
        code >= 500 -> "Google ka server busy hai, thodi der baad bolo"
        code == -1 -> "Jawab samajh nahi aaya, dobara bolo"
        else -> "Kuch gadbad hui, dobara bolo"
    }

    // Seedha text jawab (optional image ke saath). Return: (text ya null, code)
    fun ask(key: String, sys: String, user: String, imgB64: String? = null, sec: Long = 25): Pair<String?, Int> {
        val parts = JSONArray().put(JSONObject().put("text", user))
        if (imgB64 != null) {
            parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", imgB64)))
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
        val (code, txt, _) = gemini(key, body.toString(), sec)
        if (code >= 400 || code == 0) return Pair(null, code)
        return try {
            Pair(JSONObject(txt).getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
                .getJSONArray("parts").getJSONObject(0).getString("text").trim(), code)
        } catch (e: Exception) { Pair(null, -1) }
    }

    fun imageB64(f: File): String {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / s > 1600) s *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = s
        val bm = BitmapFactory.decodeFile(f.path, o2) ?: return ""
        val bo = ByteArrayOutputStream()
        bm.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, bo)
        return Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
    }

    fun describe(f: File, key: String): String {
        if (key.isEmpty()) return "Pehle app me API key daalo"
        val b64 = imageB64(f)
        if (b64.isEmpty()) return "Photo padh nahi paaya"
        val sys = "You are Jarvis, a friendly Hinglish voice assistant. The user pointed the phone camera at something and asked what it is. " +
            "Describe it in 2 short natural Hinglish sentences (Roman script). If there is text, read the key part."
        val (t, code) = ask(key, sys, "Ye kya hai?", b64, 35)
        return t ?: errSay(code)
    }

    fun get(url: String, sec: Long): Int {
        val c = client.newBuilder().callTimeout(sec, TimeUnit.SECONDS).build()
        c.newCall(Request.Builder().url(url).build()).execute().use { return it.code }
    }
}
