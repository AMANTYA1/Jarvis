package com.jarvis.mine

import okhttp3.Dns
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.net.Inet4Address
import java.net.InetAddress
import java.util.concurrent.TimeUnit

object Net {
    val client: OkHttpClient = OkHttpClient.Builder()
        .dns(object : Dns {
            override fun lookup(hostname: String): List<InetAddress> =
                Dns.SYSTEM.lookup(hostname).sortedBy { it !is Inet4Address }
        })
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(40, TimeUnit.SECONDS)
        .callTimeout(60, TimeUnit.SECONDS)
        .build()

    fun post(url: String, key: String, body: String): Pair<Int, String> {
        val req = Request.Builder().url(url).header("X-goog-api-key", key)
            .post(body.toRequestBody("application/json".toMediaType())).build()
        client.newCall(req).execute().use { return Pair(it.code, it.body?.string() ?: "") }
    }
}
