package com.jarvis.mine

import okhttp3.Dns
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.net.Inet4Address
import java.net.InetAddress
import java.util.concurrent.TimeUnit

object Net {
    val client: OkHttpClient = OkHttpClient.Builder()
        .dns(object : Dns {
            override fun lookup(hostname: String): List<InetAddress> =
                Dns.SYSTEM.lookup(hostname).sortedBy { it !is Inet4Address }
        })
        .protocols(listOf(Protocol.HTTP_1_1))
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .callTimeout(30, TimeUnit.SECONDS)
        .build()

    private val models = listOf("gemini-flash-lite-latest", "gemini-flash-latest", "gemini-2.5-flash-lite", "gemini-2.5-flash")
    var goodModel: String? = null

    fun post(url: String, key: String, body: String, sec: Long = 15): Pair<Int, String> {
        val c = client.newBuilder().callTimeout(sec, TimeUnit.SECONDS).readTimeout(sec, TimeUnit.SECONDS).build()
        val req = Request.Builder().url(url).header("X-goog-api-key", key)
            .post(body.toRequestBody("application/json".toMediaType())).build()
        c.newCall(req).execute().use { return Pair(it.code, it.body?.string() ?: "") }
    }

    fun gemini(key: String, body: String): Triple<Int, String, String> {
        val order = (listOfNotNull(goodModel) + models).distinct()
        var last = Triple(0, "no response", "")
        for (m in order) {
            try {
                val (c, t) = post("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent", key, body)
                last = Triple(c, t, m)
                if (c < 400) { goodModel = m; return last }
                if (c == 401 || c == 403 || (c == 400 && t.contains("API key"))) return last
            } catch (e: Exception) {
                last = Triple(0, e.javaClass.simpleName, m)
            }
        }
        return last
    }

    fun get(url: String, sec: Long): Int {
        val c = client.newBuilder().callTimeout(sec, TimeUnit.SECONDS).build()
        c.newCall(Request.Builder().url(url).build()).execute().use { return it.code }
    }
}
