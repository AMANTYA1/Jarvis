package com.jarvis.mine

import android.graphics.BitmapFactory
import android.util.Base64
import okhttp3.Dns
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.Inet4Address
import java.net.InetAddress
import java.util.concurrent.TimeUnit

object Net {
    val client: OkHttpClient = OkHttpClient.Builder()
        .dns(object : Dns {
            override fun lookup(hostname: String): List<InetAddress> =
                Dns.SYSTEM.lookup(hostname).sortedBy { it !is Inet4Address }
        })
        .protocols(listOf(Protocol.HTTP_1_1))
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .callTimeout(30, TimeUnit.SECONDS)
        .build()

    private val models = listOf("gemini-flash-lite-latest", "gemini-flash-latest", "gemini-2.5-flash-lite", "gemini-2.5-flash")
    var goodModel: String? = null
    // Settings Dashboard me chuna hua model ("auto" = apne aap)
    @Volatile var preferred: String = "auto"
    // Natural awaaz ke liye Gemini TTS model
    var ttsModel = "gemini-2.5-flash-preview-tts"

    fun post(url: String, key: String, body: String, sec: Long = 15): Pair<Int, String> {
        val c = client.newBuilder().callTimeout(sec, TimeUnit.SECONDS).readTimeout(sec, TimeUnit.SECONDS).build()
        val req = Request.Builder().url(url).header("X-goog-api-key", key)
            .post(body.toRequestBody("application/json".toMediaType())).build()
        c.newCall(req).execute().use { return Pair(it.code, it.body?.string() ?: "") }
    }

    private fun retryable(c: Int) = c == 0 || c == 429 || c == 500 || c == 502 || c == 503 || c == 504

    // Sab models try karta hai; limit (429) ya server busy (503) par thoda ruk kar dobara try karta hai
    fun gemini(key: String, body: String, sec: Long = 15): Triple<Int, String, String> {
        val order = (listOfNotNull(preferred.takeIf { it != "auto" && it.isNotBlank() }, goodModel) + models).distinct()
        val deadline = System.currentTimeMillis() + 40000L
        var last = Triple(0, "no response", "")
        for (pass in 0..1) {
            var anyRetry = false
            for (m in (if (pass == 0) order else order.take(2))) {
                if (System.currentTimeMillis() > deadline) return last
                try {
                    val (c, t) = post("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent", key, body, sec)
                    last = Triple(c, t, m)
                    if (c < 400) { goodModel = m; return last }
                    if (c == 401 || c == 403 || (c == 400 && t.contains("API key"))) return last
                    if (retryable(c)) anyRetry = true
                } catch (e: Exception) {
                    last = Triple(0, e.javaClass.simpleName, m)
                    anyRetry = true
                }
            }
            if (pass == 1 || !anyRetry) break
            try { Thread.sleep(2500) } catch (e: InterruptedException) { break }
        }
        return last
    }

    // Gemini se natural awaaz. Return: 24kHz 16-bit mono PCM bytes, fail par null (tab phone ki awaaz use hoti hai)
    fun ttsGemini(key: String, text: String, voice: String): ByteArray? {
        val prompt = "Say in a warm, natural, friendly conversational tone, like a real person talking to a friend: $text"
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig",
                    JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
        return try {
            val (code, txt) = post("https://generativelanguage.googleapis.com/v1beta/models/$ttsModel:generateContent", key, body.toString(), 20)
            if (code >= 400) return null
            val part = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
            val inl = part.optJSONObject("inlineData") ?: part.optJSONObject("inline_data") ?: return null
            Base64.decode(inl.getString("data"), Base64.DEFAULT)
        } catch (e: Exception) { null }
    }

    // Error code ko bolne layak Hinglish me badalta hai
    fun errSay(code: Int): String = when {
        code == 401 || code == 403 -> "API key me dikkat hai, app me check karo"
        code == 400 -> "Request me dikkat aayi, dobara bolo"
        code == 429 -> "Abhi API ki limit lag gayi hai, thodi der baad bolo"
        code == 0 -> "Net ya server se jawab nahi aaya, thodi der baad bolo"
        code >= 500 -> "Google ka server busy hai, thodi der baad bolo"
        code == -1 -> "Jawab samajh nahi aaya, dobara bolo"
        else -> "Kuch gadbad hui, dobara bolo"
    }

    // Seedha text jawab (optional image ke saath). Return: (text ya null, code)
    fun ask(key: String, sys: String, user: String, imgB64: String? = null, sec: Long = 25): Pair<String?, Int> {
        val parts = JSONArray().put(JSONObject().put("text", user))
        if (imgB64 != null) {
            parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", imgB64)))
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
        val (code, txt, _) = gemini(key, body.toString(), sec)
        if (code >= 400 || code == 0) return Pair(null, code)
        return try {
            Pair(JSONObject(txt).getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
                .getJSONArray("parts").getJSONObject(0).getString("text").trim(), code)
        } catch (e: Exception) { Pair(null, -1) }
    }

    fun imageB64(f: File): String {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / s > 1600) s *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = s
        val bm = BitmapFactory.decodeFile(f.path, o2) ?: return ""
        val bo = ByteArrayOutputStream()
        bm.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, bo)
        return Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
    }

    fun describe(f: File, key: String): String {
        if (key.isEmpty()) return "Pehle app me API key daalo"
        val b64 = imageB64(f)
        if (b64.isEmpty()) return "Photo padh nahi paaya"
        val sys = "You are Jarvis, a friendly Hinglish voice assistant. The user pointed the phone camera at something and asked what it is. " +
            "Describe it in 2 short natural Hinglish sentences (Roman script). If there is text, read the key part."
        val (t, code) = ask(key, sys, "Ye kya hai?", b64, 35)
        return t ?: errSay(code)
    }

    fun get(url: String, sec: Long): Int {
        val c = client.newBuilder().callTimeout(sec, TimeUnit.SECONDS).build()
        c.newCall(Request.Builder().url(url).build()).execute().use { return it.code }
    }
}
