package com.jarvis.mine

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

class Reminder(val id: Long, val at: Long, val text: String)

class SosContact(val name: String, val number: String)

// Settings Dashboard ki saari values yahin se padhi/likhi jaati hain (SharedPreferences "j")
object Cfg {
    val MODELS = listOf(
        "auto" to "Auto (jo chale wahi use karo)",
        "gemini-flash-lite-latest" to "Flash Lite - sabse tez",
        "gemini-flash-latest" to "Flash - balanced",
        "gemini-2.5-flash" to "2.5 Flash",
        "gemini-2.5-flash-lite" to "2.5 Flash Lite",
        "gemini-pro-latest" to "Pro - sabse smart, thoda slow"
    )

    val VOICES = listOf(
        "Kore" to "Kore - firm",
        "Puck" to "Puck - upbeat",
        "Charon" to "Charon - informative",
        "Aoede" to "Aoede - breezy",
        "Leda" to "Leda - youthful",
        "Fenrir" to "Fenrir - excitable",
        "Orus" to "Orus - firm",
        "Zephyr" to "Zephyr - bright",
        "Sulafat" to "Sulafat - warm",
        "Achird" to "Achird - friendly"
    )

    fun model(p: SharedPreferences) = p.getString("model", "auto") ?: "auto"
    fun wake(p: SharedPreferences) = p.getString("wake", "") ?: ""
    fun sessionSec(p: SharedPreferences) = p.getInt("session_sec", 30)
    fun natural(p: SharedPreferences) = p.getBoolean("natural", true)
    fun voice(p: SharedPreferences) = p.getString("voice", "Kore") ?: "Kore"
    fun rate(p: SharedPreferences) = p.getInt("rate", 100)      // 50..200  (100 = normal)
    fun pitch(p: SharedPreferences) = p.getInt("pitch", 100)    // 50..150
    fun sosInstant(p: SharedPreferences) = p.getBoolean("sos_instant", false)

    fun sos(p: SharedPreferences): List<SosContact> = try {
        val a = JSONArray(p.getString("sos", "[]") ?: "[]")
        (0 until a.length()).map { val o = a.getJSONObject(it); SosContact(o.optString("n"), o.optString("p")) }
            .filter { it.number.isNotBlank() }
    } catch (e: Exception) { emptyList() }

    private fun sosSave(p: SharedPreferences, l: List<SosContact>) {
        val a = JSONArray()
        for (c in l) a.put(JSONObject().put("n", c.name).put("p", c.number))
        p.edit().putString("sos", a.toString()).apply()
    }

    fun sosAdd(p: SharedPreferences, name: String, number: String) {
        val num = number.filter { it.isDigit() || it == '+' }
        if (num.length < 5) return
        val l = sos(p).toMutableList()
        if (l.any { it.number.takeLast(10) == num.takeLast(10) }) return
        if (l.size >= 5) return
        l.add(SosContact(name.ifBlank { num }, num))
        sosSave(p, l)
    }

    fun sosRemove(p: SharedPreferences, i: Int) {
        val l = sos(p).toMutableList()
        if (i in l.indices) { l.removeAt(i); sosSave(p, l) }
    }

    fun shakeSos(p: SharedPreferences) = p.getBoolean("shake_sos", false)

    fun rems(p: SharedPreferences): List<Reminder> = try {
        val a = JSONArray(p.getString("rems", "[]") ?: "[]")
        (0 until a.length()).map { val o = a.getJSONObject(it); Reminder(o.optLong("i"), o.optLong("t"), o.optString("x")) }
            .sortedBy { it.at }
    } catch (e: Exception) { emptyList() }

    private fun remsSave(p: SharedPreferences, l: List<Reminder>) {
        val a = JSONArray()
        for (r in l) a.put(JSONObject().put("i", r.id).put("t", r.at).put("x", r.text))
        p.edit().putString("rems", a.toString()).apply()
    }

    fun remAdd(p: SharedPreferences, r: Reminder) { remsSave(p, rems(p) + r) }
    fun remRemove(p: SharedPreferences, id: Long) { remsSave(p, rems(p).filter { it.id != id }) }
}
