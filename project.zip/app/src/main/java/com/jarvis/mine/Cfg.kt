package com.jarvis.mine

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

class Reminder(val id: Long, val at: Long, val text: String)

class SosContact(val name: String, val number: String)

// Settings Dashboard ki saari values yahin se padhi/likhi jaati hain (SharedPreferences "j")
object Cfg {
    val MODELS = listOf(
        "auto" to "Auto (jo chale wahi use karo)",
        "gemini-flash-lite-latest" to "Flash Lite - sabse tez",
        "gemini-flash-latest" to "Flash - balanced",
        "gemini-2.5-flash" to "2.5 Flash",
        "gemini-2.5-flash-lite" to "2.5 Flash Lite",
        "gemini-pro-latest" to "Pro - sabse smart, thoda slow"
    )

    val VOICES = listOf(
        "Kore" to "Kore - firm",
        "Puck" to "Puck - upbeat",
        "Charon" to "Charon - informative",
        "Aoede" to "Aoede - breezy",
        "Leda" to "Leda - youthful",
        "Fenrir" to "Fenrir - excitable",
        "Orus" to "Orus - firm",
        "Zephyr" to "Zephyr - bright",
        "Sulafat" to "Sulafat - warm",
        "Achird" to "Achird - friendly"
    )

    fun model(p: SharedPreferences) = p.getString("model", "auto") ?: "auto"
    fun wake(p: SharedPreferences) = p.getString("wake", "") ?: ""
    fun sessionSec(p: SharedPreferences) = p.getInt("session_sec", 30)
    fun natural(p: SharedPreferences) = p.getBoolean("natural", true)
    fun voice(p: SharedPreferences) = p.getString("voice", "Kore") ?: "Kore"
    fun rate(p: SharedPreferences) = p.getInt("rate", 100)      // 50..200  (100 = normal)
    fun pitch(p: SharedPreferences) = p.getInt("pitch", 100)    // 50..150
    fun sosInstant(p: SharedPreferences) = p.getBoolean("sos_instant", false)

    fun sos(p: SharedPreferences): List<SosContact> = try {
        val a = JSONArray(p.getString("sos", "[]") ?: "[]")
        (0 until a.length()).map { val o = a.getJSONObject(it); SosContact(o.optString("n"), o.optString("p")) }
            .filter { it.number.isNotBlank() }
    } catch (e: Exception) { emptyList() }

    private fun sosSave(p: SharedPreferences, l: List<SosContact>) {
        val a = JSONArray()
        for (c in l) a.put(JSONObject().put("n", c.name).put("p", c.number))
        p.edit().putString("sos", a.toString()).apply()
    }

    fun sosAdd(p: SharedPreferences, name: String, number: String) {
        val num = number.filter { it.isDigit() || it == '+' }
        if (num.length < 5) return
        val l = sos(p).toMutableList()
        if (l.any { it.number.takeLast(10) == num.takeLast(10) }) return
        if (l.size >= 5) return
        l.add(SosContact(name.ifBlank { num }, num))
        sosSave(p, l)
    }

    fun sosRemove(p: SharedPreferences, i: Int) {
        val l = sos(p).toMutableList()
        if (i in l.indices) { l.removeAt(i); sosSave(p, l) }
    }

    fun shakeSos(p: SharedPreferences) = p.getBoolean("shake_sos", false)

    fun rems(p: SharedPreferences): List<Reminder> = try {
        val a = JSONArray(p.getString("rems", "[]") ?: "[]")
        (0 until a.length()).map { val o = a.getJSONObject(it); Reminder(o.optLong("i"), o.optLong("t"), o.optString("x")) }
            .sortedBy { it.at }
    } catch (e: Exception) { emptyList() }

    private fun remsSave(p: SharedPreferences, l: List<Reminder>) {
        val a = JSONArray()
        for (r in l) a.put(JSONObject().put("i", r.id).put("t", r.at).put("x", r.text))
        p.edit().putString("rems", a.toString()).apply()
    }

    fun remAdd(p: SharedPreferences, r: Reminder) { remsSave(p, rems(p) + r) }
    fun remRemove(p: SharedPreferences, id: Long) { remsSave(p, rems(p).filter { it.id != id }) }

    fun fast(p: SharedPreferences) = p.getBoolean("fast", true)

    // Dimaag #2: Groq (bahut tez)
    fun groq(p: SharedPreferences) = (p.getString("groq", "") ?: "").trim()
    fun groqOn(p: SharedPreferences) = p.getBoolean("groq_on", true)

    // Extra API keys, ek line me ek
    fun extraKeys(p: SharedPreferences): List<String> =
        (p.getString("keys_extra", "") ?: "").split("\n", ",", " ").map { it.trim() }.filter { it.length > 20 }.distinct().take(4)

    // ---- Jarvis ki yaaddasht (permanent baatein) ----
    fun facts(p: SharedPreferences): List<String> = try {
        val a = JSONArray(p.getString("facts", "[]") ?: "[]")
        (0 until a.length()).map { a.getString(it) }
    } catch (e: Exception) { emptyList() }

    private fun factsSave(p: SharedPreferences, l: List<String>) {
        val a = JSONArray()
        for (f in l.takeLast(60)) a.put(f)
        p.edit().putString("facts", a.toString()).apply()
    }

    fun factAdd(p: SharedPreferences, f: String) {
        val t = f.trim()
        if (t.isEmpty()) return
        val l = facts(p)
        if (l.any { it.equals(t, true) }) return
        factsSave(p, l + t.take(200))
    }

    fun factRemove(p: SharedPreferences, i: Int) {
        val l = facts(p).toMutableList()
        if (i in l.indices) { l.removeAt(i); factsSave(p, l) }
    }

    // keyword wale facts hatao, "all" par sab. Return: kitne hate
    fun factForget(p: SharedPreferences, key: String): Int {
        val l = facts(p)
        val k = key.trim().lowercase()
        val keep = if (k.isEmpty() || k == "all" || k == "sab") emptyList() else l.filter { !it.lowercase().contains(k) }
        factsSave(p, keep)
        return l.size - keep.size
    }

    // ---- baat-cheet ka itihaas (restart ke baad bhi) ----
    fun histLoad(p: SharedPreferences): List<Pair<String, String>> = try {
        val a = JSONArray(p.getString("hist", "[]") ?: "[]")
        (0 until a.length()).map { val o = a.getJSONObject(it); Pair(o.optString("r"), o.optString("t")) }
    } catch (e: Exception) { emptyList() }

    fun histSave(p: SharedPreferences, h: List<Pair<String, String>>) {
        val a = JSONArray()
        for ((r, t) in h.takeLast(12)) a.put(JSONObject().put("r", r).put("t", t.take(600)))
        p.edit().putString("hist", a.toString()).apply()
    }

    // ---- auto-reply ki list restart ke baad bhi ----
    fun autoSave(p: SharedPreferences) {
        p.edit().putBoolean("ar_all", AutoReply.all).putString("ar_style", AutoReply.style)
            .putStringSet("ar_chats", HashSet(AutoReply.chats)).apply()
    }

    fun autoLoad(p: SharedPreferences) {
        AutoReply.all = p.getBoolean("ar_all", false)
        AutoReply.style = p.getString("ar_style", "natural, friendly") ?: "natural, friendly"
        AutoReply.chats.clear()
        AutoReply.chats.addAll(p.getStringSet("ar_chats", emptySet()) ?: emptySet())
    }
}
